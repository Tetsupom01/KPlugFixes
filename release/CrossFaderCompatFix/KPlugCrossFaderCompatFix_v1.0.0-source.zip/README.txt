﻿KPlugCrossFaderCompatFix v1.0.0
FIRST REQUEST WINS

v0.7.0は採用不可。
クラッシュは止まったが、busyでない正規要求までExisting transitionだけを理由にDROPした。

v1.0.0の本質:
- HFlag.selectAnimationListInfo の最初の非null書き込みだけ通す
- gate中の2件目以降の非null書き込みはsetter Prefixで拒否
- nullクリアは必ず通す
- 最初の要求が既存transition中ならHSceneProc.Updateで保持し、安全になるまでChangeAnimatorを呼ばない
- 安全条件はCrossFader false + 全female/male Animator全layer非遷移を2フレーム連続
- ChangeAnimator実行後も同じ安定条件までgateを維持
- gate解除後は新しい要求を普通に受け付ける

変更しない:
- voiceWait
- click
- ChangeAnimator本体
- runtimeAnimatorController setter
- CrossFader本体
- kPlug入力メソッド
- kPlug.dll
- Assembly-CSharp.dll

期待ログ:
[GATE START]
[BLOCK WRITE]            ← 連打時の2件目以降
[WAIT] / [WAIT STABLE 1]
[ALLOW CHANGE]
[BUSY STABLE 1]
[GATE RELEASE]

実機確認は1回だけ:
1. 普通のReturnを1回
2. 正常に変更されることを確認
3. 以前のrapid/timed Return連打を1回
4. crashしない / 動きが崩れない
5. 落ち着いた後にReturnを普通に1回
6. 次の新規要求が正常に通る

回収:
- F:\illusion\Koikatu\BepInEx\KPlugCrossFaderCompatFix.log
- 最新 output_log.txt
- crash時のみ error.log


正式版判定（2026-09-29）:
- 実機で複数回のアニメーション変更が GATE START -> ALLOW CHANGE -> GATE RELEASE まで完走
- 旧クラッシュ再現操作でも native crash / Access Violation なし
- Hシーン終了およびゲーム終了まで正常
- CrossFader 0.11 はロードされ、InTransition=True を実動作中に検出
- CrossFader本体 / SetPlayHook / CrossFadeInFixedTime は変更しない

注意:
- 最終確認ログでは BLOCK WRITE は0回。
- 後続setter書き込みの実ブロック発生自体は最終確認ログでは未観測。
- 一方、要求の安全待機と連続遷移は複数回正常完走している。
- v1.0.0は実機成功v0.8.0とロジック同一で、プラグイン版番号のみ正式化したソース。
