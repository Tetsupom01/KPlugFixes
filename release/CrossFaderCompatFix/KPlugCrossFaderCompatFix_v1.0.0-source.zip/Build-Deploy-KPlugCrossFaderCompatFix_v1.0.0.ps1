﻿$ErrorActionPreference = "Stop"

$ToolName = "KPlugCrossFaderCompatFix"
$Version = "1.0.0"
$GameRoot = "F:\illusion\Koikatu"

$DeployDir = Join-Path $GameRoot "BepInEx\plugins\test"
$DeployDll = Join-Path $DeployDir "KPlugCrossFaderCompatFix.dll"
$DedicatedLog = Join-Path $GameRoot "BepInEx\KPlugCrossFaderCompatFix.log"

$BepInExDll = Join-Path $GameRoot "BepInEx\core\BepInEx.dll"
$HarmonyDll = Join-Path $GameRoot "BepInEx\core\0Harmony.dll"
$AssemblyCSharp = Join-Path $GameRoot "Koikatu_Data\Managed\Assembly-CSharp.dll"
$UnityEngineDll = Join-Path $GameRoot "Koikatu_Data\Managed\UnityEngine.dll"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Source = Join-Path $ScriptDir "KPlugCrossFaderCompatFix_v1.0.0.cs"

$ToolRoot = "C:\Tools\KPlugCrossFaderCompatFix"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$RunDir = Join-Path $ToolRoot $Stamp
$BackupDir = Join-Path $RunDir "backup"
$BuildDir = Join-Path $RunDir "build"
$SourceDir = Join-Path $RunDir "source"
$LogsDir = Join-Path $RunDir "logs"
$Manifest = Join-Path $RunDir "MANIFEST.txt"
$BuildDll = Join-Path $BuildDir "KPlugCrossFaderCompatFix.dll"

function Get-Sha256Lower([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Backup-Verified([string]$SourcePath, [string]$DestinationPath) {
    $srcHash = Get-Sha256Lower $SourcePath
    Copy-Item -LiteralPath $SourcePath -Destination $DestinationPath -Force
    $dstHash = Get-Sha256Lower $DestinationPath

    if ($srcHash -ne $dstHash) {
        throw "Backup SHA-256 mismatch: $SourcePath"
    }

    return $srcHash
}

foreach ($p in @($Source, $BepInExDll, $HarmonyDll, $AssemblyCSharp, $UnityEngineDll)) {
    if (!(Test-Path -LiteralPath $p)) {
        throw "Required file not found: $p"
    }
}

New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
New-Item -ItemType Directory -Force -Path $SourceDir | Out-Null
New-Item -ItemType Directory -Force -Path $LogsDir | Out-Null
New-Item -ItemType Directory -Force -Path $DeployDir | Out-Null

Copy-Item -LiteralPath $Source -Destination (Join-Path $SourceDir (Split-Path -Leaf $Source)) -Force

$OldDeployHash = "<none>"
$OldDeployBackup = "<none>"

if (Test-Path -LiteralPath $DeployDll) {
    $OldDeployBackup = Join-Path $BackupDir "KPlugCrossFaderCompatFix.previous.dll"
    $OldDeployHash = Backup-Verified $DeployDll $OldDeployBackup
}

if (Test-Path -LiteralPath $DedicatedLog) {
    $LogBackup = Join-Path $LogsDir ("KPlugCrossFaderCompatFix.previous-" + $Stamp + ".log")
    Copy-Item -LiteralPath $DedicatedLog -Destination $LogBackup -Force
    Remove-Item -LiteralPath $DedicatedLog -Force
}

$Csc64 = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$Csc32 = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if (Test-Path -LiteralPath $Csc64) {
    $Csc = $Csc64
}
elseif (Test-Path -LiteralPath $Csc32) {
    $Csc = $Csc32
}
else {
    throw "Framework v4.0 csc.exe not found."
}

Write-Host "[INFO] Compiler: $Csc"
Write-Host "[INFO] Building $ToolName v$Version ..."

& $Csc `
    /nologo `
    /target:library `
    /optimize+ `
    "/out:$BuildDll" `
    "/reference:$BepInExDll" `
    "/reference:$HarmonyDll" `
    "/reference:$AssemblyCSharp" `
    "/reference:$UnityEngineDll" `
    "$Source"

if ($LASTEXITCODE -ne 0) {
    throw "C# build failed: exit code $LASTEXITCODE"
}

if (!(Test-Path -LiteralPath $BuildDll)) {
    throw "Build output not found: $BuildDll"
}

$BuildHash = Get-Sha256Lower $BuildDll
Copy-Item -LiteralPath $BuildDll -Destination $DeployDll -Force
$DeployHash = Get-Sha256Lower $DeployDll

if ($BuildHash -ne $DeployHash) {
    throw "Deploy SHA-256 mismatch."
}

$ManifestLines = @()
$ManifestLines += "Tool=$ToolName"
$ManifestLines += "Version=$Version"
$ManifestLines += "Executed=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
$ManifestLines += "GameRoot=$GameRoot"
$ManifestLines += "Compiler=$Csc"
$ManifestLines += "Source=$Source"
$ManifestLines += "BuildOutput=$BuildDll"
$ManifestLines += "BuildSHA256=$BuildHash"
$ManifestLines += "DeployPath=$DeployDll"
$ManifestLines += "DeploySHA256=$DeployHash"
$ManifestLines += "PreviousDeploySHA256=$OldDeployHash"
$ManifestLines += "PreviousDeployBackup=$OldDeployBackup"
$ManifestLines += "Purpose=First non-null selectAnimationListInfo request wins; later non-null writes are blocked until first transaction settles."
$ManifestLines += "Wait=CrossFader false + all female/male Animator layers non-transition for 2 consecutive Update frames."
$ManifestLines += "NullClear=Always allowed."
$ManifestLines += "NextAction=One runtime validation; stop if behavior is abnormal."
$ManifestLines | Set-Content -LiteralPath $Manifest -Encoding UTF8

Write-Host ""
Write-Host "====================================================="
Write-Host " BUILD + DEPLOY COMPLETE"
Write-Host "====================================================="
Write-Host "Version : $Version"
Write-Host "DLL     : $DeployDll"
Write-Host "SHA-256 : $DeployHash"
Write-Host ""
Write-Host "Runtime validation:"
Write-Host "  1. Launch Koikatu and enter the same H situation."
Write-Host "  2. First perform ONE normal Return change."
Write-Host "  3. Confirm it changes normally after any necessary short wait."
Write-Host "  4. Then perform the former rapid/timed Return trigger once."
Write-Host "  5. Confirm no crash and no abnormal motion."
Write-Host "  6. After fully settled, press Return once normally again."
Write-Host ""
Write-Host "Upload:"
Write-Host "  $DedicatedLog"
Write-Host "  latest output_log.txt"
Write-Host "  error.log only if a native crash occurs"
