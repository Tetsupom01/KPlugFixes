@echo off
setlocal
cd /d "%~dp0"

echo =====================================================
echo  KPlugCrossFaderCompatFix v1.0.0
echo  FIRST REQUEST WINS
echo =====================================================
echo.
echo First non-null animation request is accepted.
echo Later non-null requests are blocked until the first transaction settles.
echo Null clear is always allowed.
echo.

set "PS1=%~dp0Build-Deploy-KPlugCrossFaderCompatFix_v1.0.0.ps1"

if not exist "%PS1%" goto :missing

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "ERR=%ERRORLEVEL%"

echo.
if not "%ERR%"=="0" goto :failed

echo =====================================================
echo  SUCCESS
echo =====================================================
echo.
echo Launch Koikatu for ONE runtime validation.
echo.
pause
exit /b 0

:missing
echo [ERROR] PowerShell script not found:
echo   %PS1%
echo.
pause
exit /b 1

:failed
echo [ERROR] Build/deploy failed. Exit code: %ERR%
echo Do NOT use this run as behavior evidence.
echo.
pause
exit /b %ERR%
