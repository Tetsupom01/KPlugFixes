HPoint Bench Route Fix v1.0.0 | Independent build, officially archived (2026-11-07)

PURPOSE
A narrowly scoped BepInEx/Harmony patch for Koikatu's H-point movement.
When the player selects “Bench Fellatio” (ベンチフェラ) but the prior insertion
animation remains, the patch redirects the matching case to the game's
existing animation-reselection path. It does not implement custom animation
or modify IK, Reset, or CrossFader behavior.

COMPATIBILITY AND REQUIREMENTS
- Koikatu 5.1 with the exact supported Assembly-CSharp.dll SHA-256:
  0038281CAF8DF48A7903C55DC389642EEEB3F2A9114BD9D68AC11C8AC0396BC5
- BepInEx and Harmony are required. Build references: BepInEx 5.4.23.5,
  0Harmony 2.9.0.0. Other versions are not guaranteed.
- kPlug and CrossFader are not code-level requirements; operation without
  kPlug has not been tested on an actual game installation.
- The patch does not activate when the Assembly-CSharp.dll hash differs.

INSTALL / UPDATE
1. Close Koikatu completely.
2. Back up any existing HPointBenchRouteFix.dll and record its path and hash.
   Avoid duplicate DLLs under BepInEx/plugins/, especially an older copy in
   BepInEx/plugins/KPlugFixes/. Do not install with HPointBenchRouteFixTrial.dll.
3. Extract this ZIP at the Koikatu game root, preserving directory structure.
   The DLL goes to BepInEx/plugins/HPointBenchRouteFix.dll.
4. On launch, check BepInEx/HPointBenchRouteFix.log for READY.
   PATCH_NOT_APPLIED or initialization errors mean the patch is not active.
   The log is overwritten on each game launch: copy it before another run.

VERIFY
- From an insertion animation at a chair H-point, select Bench Fellatio
  and confirm it switches to the service animation.
- Verify ordinary H-point transitions and the UI remain functional.
- Repeat after restarting the game (the second-launch result is not recorded).

UNINSTALL / RESTORE
With Koikatu closed, remove only BepInEx/plugins/HPointBenchRouteFix.dll.
If you backed up an older copy, restore it to its original location.
No game DLL, kPlug DLL, or CrossFader DLL is replaced by this package.

VALIDATION STATUS AND KNOWN LIMITS
- In the earlier v0.1.0 trial, the reload guard fired four times and the user
  reported no apparent issue.
- The present v1.0.0 Independent RC1 binary was installed and the user reported
  “no apparent issue” on November 7, 2026.
- Independent-RC1 second-launch behavior, final log review, and operation in
  a kPlug-free installation have not been documented.
- Other pose, IK, and Enter-input problems are out of scope.
- This installer and its exact source are published on GitHub with the user's
  approval. Publication does not imply the unrecorded regression tests passed.

DLL SHA-256: 170757DA0A4880CF2F8CF23C7E206C70BC6F9487F0051AAB470353D57A3408BD
