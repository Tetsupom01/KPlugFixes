HPoint Bench Route Fix v1.0.0｜独立版・正式保存（2026-11-07）

【概要】
KoikatuのHポイント移動メニューで「ベンチフェラ」を選んでも、移動前の
挿入モーションが残ってしまう場合に、ゲーム標準のモーション再選択経路へ
進ませるためのBepInEx/Harmony用の局所パッチです。

【対応環境・依存関係】
・対象：Koikatu 5.1（指定したAssembly-CSharp.dllのSHA-256と一致する環境）
・必要：BepInEx、Harmony（ビルド時参照：BepInEx 5.4.23.5、0Harmony 2.9.0.0）
・kPlug、CrossFaderはコード上の必須依存ではありません。
  ただし、kPlugを外した構成での実機動作は未確認です。
・Assembly-CSharp.dllのSHA-256が基準と異なる場合はパッチを適用しません。
  基準SHA-256：0038281CAF8DF48A7903C55DC389642EEEB3F2A9114BD9D68AC11C8AC0396BC5

【導入・更新】
1. Koikatuを完全に終了します。
2. 既存の同名DLLがある場合は、その場所とSHA-256を確認して退避します。
   BepInEx/plugins/ 以下に HPointBenchRouteFix.dll が複数存在しないようにし、
   旧版の BepInEx/plugins/KPlugFixes/HPointBenchRouteFix.dll や
   試験版の HPointBenchRouteFixTrial.dll との同時導入は避けてください。
3. 本ZIPをKoikatuのゲームルートへフォルダー構成のまま展開します。
   配置されるDLL：BepInEx/plugins/HPointBenchRouteFix.dll
4. 起動後、BepInEx/HPointBenchRouteFix.log 内に「READY」があることを確認します。
   「PATCH_NOT_APPLIED」や初期化エラーがある場合は、適用できていません。
   ログはゲーム起動時に上書きされるため、比較する場合は終了前に保全してください。

【動作確認】
・椅子の挿入状態から「ベンチフェラ」へ移動し、奉仕モーションに切り替わること。
・他の通常のHポイント移動と画面UIに異常がないこと。
・ゲームを一度終了して再起動後も同じ動作となること（再起動結果は未記録）。

【解除・復元】
Koikatu終了後、BepInEx/plugins/HPointBenchRouteFix.dll を除去します。
上書き前に退避した原本がある場合は、元の位置に戻してください。
Koikatu本体DLLやkPlug/CrossFaderのDLLを置換するパッチではありません。

【検証状態と制限】
・修正の元となるv0.1.0試験版では、切替補正が4回発火し、ユーザーが
  「特に問題ない」と評価しました。
・本v1.0.0 Independent RC1のDLLは、ユーザーが実機へ導入し、
  「問題なさそう」と報告しています（2026-11-07）。
・独立版RC1の再起動後確認、動作ログの最終照合、kPlug不使用構成での
  実機確認は、現時点で記録されていません。
・ほかのHポイント移動時の姿勢崩れ、IK、Enter無反応等は修正対象外です。
・GitHubでの配布は利用者向けにソースと導入ZIPを公開するものです。
  ただし、公開は未記録の再起動テスト等まで検証済みであることを意味しません。

DLL SHA-256：170757DA0A4880CF2F8CF23C7E206C70BC6F9487F0051AAB470353D57A3408BD
