﻿【KPlugPoseBridge.dll v0.2.0.1】日本語での導入方法

目的：kPlugの体位選択にある挿入体位を、Koikatu本体のH画面の体位一覧へ反映します（mode 2のみ）。

導入手順
1. Koikatuを完全に終了する。
2. 既存の同名DLLをバックアップする。
3. このZIPのBepInExフォルダをゲーム本体フォルダに展開する。
4. 配置先：BepInEx/plugins/KPlugFixes/KPlugPoseBridge.dll
5. 旧配置先（BepInEx/plugins直下や別フォルダ）の同名DLLを残さない。
   二重配置は競合の原因となるため、古い版の場所を確認する。
6. Koikatu起動後、BepInEx/LogOutput.logで対象DLLのLoadingが1回か確認する。

注意：全体位を網羅した実機検証は未実施です。
ゲーム本体・kPlug.dllは配布しません。
DLLは既存の正式版と同一で、ZIP内の配置先と説明文のみ変更しています。

戻し方：ゲームを終了し、新DLLを外して保存した旧DLLを戻してください。
DLL SHA-256：F1A35FF5A1849001D2705DD3F4C368FCB9A309170B51F244AEB1FD99583C9142
https://github.com/Tetsupom01/KPlugFixes
