KPlugPoseBridge.dll v0.2.0.1 - English installation guide

Purpose: Synchronizes kPlug's insertion pose list with the standard H-scene animation menu (mode 2 only).

Installation:
1. Exit Koikatu completely.
2. Back up any existing DLL with the same name.
3. Extract the BepInEx folder in this ZIP into the game root.
4. Target: BepInEx/plugins/KPlugFixes/KPlugPoseBridge.dll
5. Remove the old copy from the plugins root or another subfolder only after backing it up.
   Avoid loading duplicate copies of the same plugin.
6. Restart and confirm exactly one Loading entry in BepInEx/LogOutput.log.

Known limitations: Not every pose has been exhaustively tested in-game.
The DLL is byte-identical to the previous official build; only ZIP layout/docs changed.

Uninstall: Exit the game, remove this DLL and restore your saved previous DLL.
DLL SHA-256: F1A35FF5A1849001D2705DD3F4C368FCB9A309170B51F244AEB1FD99583C9142
https://github.com/Tetsupom01/KPlugFixes
