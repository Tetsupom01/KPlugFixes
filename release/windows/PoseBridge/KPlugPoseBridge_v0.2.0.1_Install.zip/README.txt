KPlug Pose Bridge v0.2.0.1 - Installer (2026-10-31)

INSTALL: Close Koikatu. Extract this ZIP to your Koikatu game directory, preserving paths.
Target: BepInEx\plugins\KPlugPoseBridge.dll
Back up any prior DLL first. Do not leave duplicate versions elsewhere under BepInEx\plugins.

Purpose: Mirror the kPlug Pose Selector insertion-pose list in the main H insertion menu.
Patch: ExtraAnimManager.Start + HSceneProc.CreateListAnimationFileName.
If the H list is built before ExtraAnimManager.Start, synchronization is deferred.

This package contains the exact DLL collected from the running Koikatu installation
on 2026-10-31; it is NOT a rebuilt binary.
DLL SHA-256: F1A35FF5A1849001D2705DD3F4C368FCB9A309170B51F244AEB1FD99583C9142
Validated: Loaded as KPlug Pose Bridge 0.2.0.1, Patch applied, startup active.
Functional pose-by-pose testing of this exact binary was not repeated as part of this collection.
Requires Koikatu, kPlug 3.6.0, BepInEx 5.4.x and compatible Harmony runtime.
Source: src/PoseBridge/KPlugPoseBridge_v0.2.0.1.cs in Tetsupom01/KPlugFixes.
No game binaries or third-party dependencies are redistributed.
