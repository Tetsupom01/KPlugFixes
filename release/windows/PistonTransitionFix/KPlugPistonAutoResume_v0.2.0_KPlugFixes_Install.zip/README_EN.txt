KPlugPistonAutoResume v0.2.0 | English README

PURPOSE
Automatically resumes piston motion through the normal Go path after the Animator reaches an appropriate safe state.

ENVIRONMENT / DEPENDENCIES
Existing validated baseline: Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5.
Historical kPlug.dll SHA-256: 880b34324bf1563a1e09a02a6c0960918270fae7463132d47e5fc813bcf4607f
Compatibility with other environments has not been established; do not replace your kPlug.dll based on this value.

INSTALL / UPDATE
1. Fully exit Koikatu.
2. Locate any installed KPlugPistonAutoResume.dll; record its path and SHA-256, then back it up if present.
3. Extract the BepInEx folder from this ZIP into your game root.
   Destination: BepInEx/plugins/KPlugFixes/KPlugPistonAutoResume.dll
4. Check other plugin directories, including plugins/ root and plugins/test/, to avoid duplicate loads. Do not delete unknown files without checking.
5. Launch the game and check BepInEx/LogOutput.log for a successful load.

UNINSTALL / ROLLBACK
Exit the game and remove only the DLL installed by this package. Restore a previous DLL from your backup if needed.

KNOWN LIMITATIONS
Requires KPlugPistonWaitFix v1.0.0 separately. Config: BepInEx/config/local.kplug.pistonautoresume.cfg. Default wait 0.8 s; Enabled=false disables it. Another action cancels pending resumption.
The previously published runtime-tested DLL is packaged byte-for-byte without modification. The new installer ZIP has not been separately runtime-tested.

SHA-256
DLL: 0abaa27f88469dcb9e73a1f83878da522e61f3a73cd3a7df9aad4ad668290f4f
Original DLL-only ZIP: a7e8a19766570f441f6d059053eeb0333ae266b7b99824a0e75c72793b5c1c48
Current ZIP: see the GitHub root SHA256SUMS.txt.

Japanese documentation: https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/PistonTransitionFix/README_ja.md
Source: https://github.com/Tetsupom01/KPlugFixes/blob/main/src/PistonTransitionFix/AutoResume/KPlugPistonAutoResume_v0.2.0.cs
