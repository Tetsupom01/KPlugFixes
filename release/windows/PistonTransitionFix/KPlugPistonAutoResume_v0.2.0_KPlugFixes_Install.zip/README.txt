﻿KPlugPistonAutoResume v0.2.0｜日本語README

【用途】
挿入モーション切替後、実Animatorの安全な状態を待って、元のGo処理でピストン動作を自動再開します。

【対応環境・依存】
既存の検証基準：Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5。
当時の参照kPlug.dll SHA-256：880B34324BF1563A1E09A02A6C0960918270FAE7463132D47E5FC813BCF4607F
異なる環境での互換性は未検証です。元のkPlug.dllを置き換える指示ではありません。

【導入・更新】
1. Koikatuを終了します。
2. 既存KPlugPistonAutoResume.dllの配置先・SHA-256を確認し、使用中ならバックアップします。
3. このZIPのBepInExフォルダをゲーム本体フォルダへ展開します。
   導入先：BepInEx/plugins/KPlugFixes/KPlugPistonAutoResume.dll
4. 旧plugins直下・plugins/test等、他のフォルダに同名DLLが残っていないか確認してください。二重ロードを避け、不明なファイルを無断削除しないでください。
5. 起動後、BepInEx/LogOutput.logで対象DLLが正常にロードされることを確認します。

【アンインストール・復元】
ゲームを終了して、このZIPで導入した対象DLLだけを外します。旧版が必要ならバックアップから復元してください。

【既知の制約】
KPlugPistonWaitFix v1.0.0が別途必要。設定はBepInEx/config/local.kplug.pistonautoresume.cfg。標準待機0.8秒、Enabled=falseで無効化。別操作が入ると再開予約を取り消します。
元の実機成功DLLを無変更で再梱包しています。新しいZIPの導入動作そのものは実機で未検証です。

【SHA-256】
DLL：0ABAA27F88469DCB9E73A1F83878DA522E61F3A73CD3A7DF9AAD4AD668290F4F
旧DLL単体ZIP：A7E8A19766570F441F6D059053EEB0333AE266B7B99824A0E75C72793B5C1C48
新ZIP：GitHubルートのSHA256SUMS.txtに記載。

技術説明：https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/PistonTransitionFix/README_ja.md
ソース：https://github.com/Tetsupom01/KPlugFixes/blob/main/src/PistonTransitionFix/AutoResume/KPlugPistonAutoResume_v0.2.0.cs
