KPlugPistonWaitFix v1.0.0 | English README

PURPOSE
Fixes an insertion-animation wait condition that can block later navigation after Numpad 7 / Backspace.

ENVIRONMENT / DEPENDENCIES
Existing validated baseline: Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5.
Historical kPlug.dll SHA-256: 880b34324bf1563a1e09a02a6c0960918270fae7463132d47e5fc813bcf4607f
Compatibility with other environments has not been established; do not replace your kPlug.dll based on this value.

INSTALL / UPDATE
1. Fully exit Koikatu.
2. Locate any installed KPlugPistonWaitFix.dll; record its path and SHA-256, then back it up if present.
3. Extract the BepInEx folder from this ZIP into your game root.
   Destination: BepInEx/plugins/KPlugFixes/KPlugPistonWaitFix.dll
4. Check other plugin directories, including plugins/ root and plugins/test/, to avoid duplicate loads. Do not delete unknown files without checking.
5. Launch the game and check BepInEx/LogOutput.log for a successful load.

UNINSTALL / ROLLBACK
Exit the game and remove only the DLL installed by this package. Restore a previous DLL from your backup if needed.

KNOWN LIMITATIONS
The original temporary ForceCoupleIdle(true) stop remains. Auto-resumption is provided by the separate AutoResume plugin.
The previously published runtime-tested DLL is packaged byte-for-byte without modification. The new installer ZIP has not been separately runtime-tested.

SHA-256
DLL: c134bde2967194477c686e26ebca12010c3d81653e97a7b226e33a6b7294eabd
Original DLL-only ZIP: 955de4cc6c72d0e852cd4f3b75e7e13bf6efd9094d84cc5d4096427adb3be48a
Current ZIP: see the GitHub root SHA256SUMS.txt.

Japanese documentation: https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/PistonTransitionFix/README_ja.md
Source: https://github.com/Tetsupom01/KPlugFixes/blob/main/src/PistonTransitionFix/WaitFix/KPlugPistonWaitFix_v1.0.0.cs
