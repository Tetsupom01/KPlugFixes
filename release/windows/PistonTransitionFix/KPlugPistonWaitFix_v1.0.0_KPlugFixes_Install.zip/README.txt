﻿KPlugPistonWaitFix v1.0.0｜日本語README

【用途】
テンキー7／Backspaceで挿入アニメーションを変更した後、切替操作が反応しなくなる待機状態を修正します。

【対応環境・依存】
既存の検証基準：Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5。
当時の参照kPlug.dll SHA-256：880B34324BF1563A1E09A02A6C0960918270FAE7463132D47E5FC813BCF4607F
異なる環境での互換性は未検証です。元のkPlug.dllを置き換える指示ではありません。

【導入・更新】
1. Koikatuを終了します。
2. 既存KPlugPistonWaitFix.dllの配置先・SHA-256を確認し、使用中ならバックアップします。
3. このZIPのBepInExフォルダをゲーム本体フォルダへ展開します。
   導入先：BepInEx/plugins/KPlugFixes/KPlugPistonWaitFix.dll
4. 旧plugins直下・plugins/test等、他のフォルダに同名DLLが残っていないか確認してください。二重ロードを避け、不明なファイルを無断削除しないでください。
5. 起動後、BepInEx/LogOutput.logで対象DLLが正常にロードされることを確認します。

【アンインストール・復元】
ゲームを終了して、このZIPで導入した対象DLLだけを外します。旧版が必要ならバックアップから復元してください。

【既知の制約】
元のForceCoupleIdle(true)による一時停止は残ります。自動再開は別のAutoResumeプラグインの機能です。
元の実機成功DLLを無変更で再梱包しています。新しいZIPの導入動作そのものは実機で未検証です。

【SHA-256】
DLL：C134BDE2967194477C686E26EBCA12010C3D81653E97A7B226E33A6B7294EABD
旧DLL単体ZIP：955DE4CC6C72D0E852CD4F3B75E7E13BF6EFD9094D84CC5D4096427ADB3BE48A
新ZIP：GitHubルートのSHA256SUMS.txtに記載。

技術説明：https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/PistonTransitionFix/README_ja.md
ソース：https://github.com/Tetsupom01/KPlugFixes/blob/main/src/PistonTransitionFix/WaitFix/KPlugPistonWaitFix_v1.0.0.cs
