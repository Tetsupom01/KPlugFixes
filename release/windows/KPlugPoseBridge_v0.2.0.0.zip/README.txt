﻿KPlug Pose Bridge v0.2.0.0

Purpose
-------
Synchronize the vanilla/main H insertion-position list (mode 2) with the same
canonical list kPlug Pose Selector uses.

Confirmed kPlug path
--------------------
ToolAnimSelector.GetAvailablePiston()
  -> canonical pose names
ParserAnim.GetHAnim(canonical)
  -> HSceneProc.AnimationListInfo actually used by kPlug

Implementation
--------------
- Patches ExtraAnimManager.Start postfix for initial synchronization.
- Patches HSceneProc.CreateListAnimationFileName(bool,int) postfix so a later
  H-point/category rebuild is synchronized again.
- Resolves every canonical pose BEFORE changing lstUseAnimInfo[2].
- If even one pose cannot be resolved, SYNC_ABORT is logged and the existing
  vanilla list is left untouched.
- Uses kPlug's button-name dictionary for display labels.
- Shallow-clones AnimationListInfo before changing nameAnimation so the source
  object is not renamed.

Scope
-----
- mode 2 (insertion) only.
- No service/3P/lesbian expansion in this version.
- Existing known-good non-PoseBridge fixes are not touched.

Test
----
1. Normal H, ordinary floor point.
2. Open vanilla insertion list without opening Pose Selector.
3. Check count/contents.
4. Select one vanilla-origin and one kPlug-added pose from vanilla UI.
5. Move to desk/wall H point and verify the vanilla list changes.
6. Optionally compare against Pose Selector at the same point.
7. Send output_log.txt.
