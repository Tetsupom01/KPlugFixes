Sideloader HList Name Cache v0.1.0 -- frozen success build

1. Keep this whole folder; output is generated next to the BAT under Results.
2. Close Koikatu before either BAT. Do not run alongside previous experimental cache or HListDiag.
3. Run 01_Install_Stable.bat to install the EXACT DLL tested in the second successful session. This does not recompile.
4. Existing original Sideloader.dll, Assembly-CSharp.dll, kPlug, PoseBridge are NEVER replaced.
5. If the game already contains SideloaderHListNameCache.dll / .output.txt or this folder has an active manifest, install refuses to overwrite.
6. On the next game run, check BepInEx LogOutput.log for PATCH_OK. No runtime behavior is represented as verified by this archive; only former experimental v0.1.0 tests passed.
7. Run 02_Collect_Remove_Stable.bat after closing the game to collect the logs and remove ONLY this patch DLL/pointer if exact hashes match.
8. Keep the generated install and collect ZIPs. Failed operations emit a ZIP too if possible. No original game DLL is edited.
9. The intermittent HPointMove pose-collapse issue remains separate; the tested cache did NOT fix it.

Note: Tested DLL SHA256 differs from the first run due to recompilation; the second session EXACT binary is bundled and frozen.
