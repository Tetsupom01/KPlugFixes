// Koikatsu H list asset-name enumeration cache v0.1.0 (experimental, narrow scope).
// Affects ONLY AssetBundleCheck.GetAllAssetName(string,bool,string,bool) for six exact h/list paths
// when _WithExtension=false, manifestAssetBundleName=null/empty and isAllCheck=false.
// Never holds or changes Unity AssetBundle objects, LoadAsset, Unload, or the actual H list text.
// The original call runs on the first request; subsequent requests return a cloned string[] only.
using System;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;

namespace SideloaderHListNameCache
{
    [BepInPlugin("koikatsu.pj.sideloader.hlistnamecache", "Sideloader H List Name Cache", "0.1.0")]
    public sealed class Plugin : BaseUnityPlugin
    {
        static readonly string[] Targets = new string[] {
            "h/list/hs2suite.unity3d",
            "h/list/mmbath.unity3d",
            "h/list/mmhouse01.unity3d",
            "h/list/poolmap.unity3d",
            "h/list/purpleroom.unity3d",
            "h/list/sakuraroom.unity3d"
        };
        static readonly object Gate = new object();
        static readonly string[][] Stored = new string[6][];
        static readonly int[] Miss = new int[6];
        static readonly int[] Hit = new int[6];
        static readonly bool[] HitReported = new bool[6];
        static ManualLogSource Out;
        static StreamWriter FileOut;
        static int WarningCount;
        static bool SummaryWritten;
        private Harmony _harmony;

        private void Awake()
        {
            Out = Logger;
            OpenLog();
            Write("START v0.1.0 EXPERIMENTAL name-array-only; six exact h/list paths; _WithExtension=false, manifest=null/empty, isAllCheck=false");
            try
            {
                // Reject an unexpected game method signature rather than guessing or patching another overload.
                Type[] types = new Type[] { typeof(string), typeof(bool), typeof(string), typeof(bool) };
                MethodInfo target = typeof(AssetBundleCheck).GetMethod("GetAllAssetName",
                    BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, types, null);
                if (target == null || target.ReturnType != typeof(string[]))
                {
                    Write("ERROR signature mismatch; patch NOT installed");
                    return;
                }
                MethodInfo prefix = typeof(Plugin).GetMethod("CachePrefix", BindingFlags.NonPublic | BindingFlags.Static);
                MethodInfo postfix = typeof(Plugin).GetMethod("CachePostfix", BindingFlags.NonPublic | BindingFlags.Static);
                if (prefix == null || postfix == null) { Write("ERROR callback missing; patch NOT installed"); return; }
                _harmony = new Harmony("koikatsu.pj.sideloader.hlistnamecache");
                if (!PatchSafely(target, prefix, postfix))
                {
                    Write("ERROR Harmony.Patch failed; experimental cache NOT active");
                    return;
                }
                Write("PATCH_OK AssetBundleCheck.GetAllAssetName(string,bool,string,bool) -> string[]; other methods UNCHANGED");
            }
            catch (Exception ex) { Write("ERROR Awake: " + ex.GetType().Name + " " + ex.Message); }
        }

        private bool PatchSafely(MethodBase original, MethodInfo prefix, MethodInfo postfix)
        {
            // Supports the HarmonyX Patch overload used by this installation (same mechanism as successful diagnostic).
            MethodInfo[] methods = typeof(Harmony).GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            for (int i = 0; i < methods.Length; i++)
            {
                MethodInfo m = methods[i];
                if (m.Name != "Patch") continue;
                ParameterInfo[] ps = m.GetParameters();
                if (ps.Length < 3 || !typeof(MethodBase).IsAssignableFrom(ps[0].ParameterType)) continue;
                object[] args = new object[ps.Length];
                args[0] = original;
                bool hasPre = false, hasPost = false, good = true;
                for (int j = 1; j < ps.Length; j++)
                {
                    if (ps[j].ParameterType != typeof(HarmonyMethod)) { good = false; break; }
                    string n = (ps[j].Name ?? "").ToLowerInvariant();
                    if (n.IndexOf("prefix") >= 0) { args[j] = new HarmonyMethod(prefix); hasPre = true; }
                    else if (n.IndexOf("postfix") >= 0) { args[j] = new HarmonyMethod(postfix); hasPost = true; }
                }
                if (!good || !hasPre || !hasPost) continue;
                try { m.Invoke(_harmony, args); return true; }
                catch (Exception ex) { Warn("Harmony.Patch " + ex.GetType().Name + " " + ex.Message); }
            }
            return false;
        }

        private static int IndexOfTarget(string assetBundleName, bool withExtension, string manifestName, bool allCheck)
        {
            if (String.IsNullOrEmpty(assetBundleName) || withExtension || allCheck || !String.IsNullOrEmpty(manifestName)) return -1;
            string path = assetBundleName.Replace('\\', '/');
            if (path.StartsWith("abdata/", StringComparison.OrdinalIgnoreCase)) path = path.Substring(7);
            for (int i = 0; i < Targets.Length; i++)
                if (String.Equals(path, Targets[i], StringComparison.OrdinalIgnoreCase)) return i;
            return -1;
        }

        private static bool CachePrefix(string __0, bool __1, string __2, bool __3, ref string[] __result)
        {
            try
            {
                int idx = IndexOfTarget(__0, __1, __2, __3);
                if (idx < 0) return true; // All non-target requests run exactly as before.
                bool firstHit = false;
                int length;
                lock (Gate)
                {
                    string[] names = Stored[idx];
                    if (names == null) { Miss[idx]++; return true; } // Original first execution.
                    __result = (string[]) names.Clone(); // Caller cannot mutate the saved copy.
                    Hit[idx]++;
                    firstHit = !HitReported[idx];
                    HitReported[idx] = true;
                    length = names.Length;
                }
                if (firstHit) Write("FIRST_HIT " + Targets[idx] + " names=" + length);
                return false; // Only redundant asset-name enumeration is skipped.
            }
            catch (Exception ex)
            {
                Warn("prefix " + ex.GetType().Name + " " + ex.Message);
                return true; // Fail open: execute vanilla function.
            }
        }

        private static void CachePostfix(string __0, bool __1, string __2, bool __3, string[] __result)
        {
            try
            {
                int idx = IndexOfTarget(__0, __1, __2, __3);
                if (idx < 0 || __result == null || __result.Length == 0) return; // Never cache missing/empty results.
                for (int i = 0; i < __result.Length; i++) if (String.IsNullOrEmpty(__result[i])) return;
                bool stored = false;
                lock (Gate)
                {
                    if (Stored[idx] == null)
                    {
                        Stored[idx] = (string[]) __result.Clone();
                        stored = true;
                    }
                }
                if (stored) Write("CACHE_STORED " + Targets[idx] + " names=" + __result.Length);
            }
            catch (Exception ex) { Warn("postfix " + ex.GetType().Name + " " + ex.Message); }
        }

        private static void OpenLog()
        {
            try
            {
                string pluginDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string ptr = Path.Combine(pluginDir, "SideloaderHListNameCache.output.txt");
                if (!File.Exists(ptr)) { Out.LogError("[HListNameCache] output pointer missing; BepInEx logging remains enabled"); return; }
                string path = File.ReadAllText(ptr).Trim();
                string folder = Path.GetDirectoryName(path);
                if (String.IsNullOrEmpty(path) || !Path.IsPathRooted(path) || !Directory.Exists(folder))
                { Out.LogError("[HListNameCache] invalid output path; BepInEx logging remains enabled"); return; }
                FileOut = new StreamWriter(new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read), System.Text.Encoding.UTF8);
                FileOut.AutoFlush = true;
            }
            catch (Exception ex) { Out.LogWarning("[HListNameCache] File log unavailable: " + ex.Message); }
        }

        private static void Write(string value)
        {
            lock (Gate)
            {
                string text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " " + value;
                try { if (FileOut != null) FileOut.WriteLine(text); }
                catch { /* A file-log failure must not affect game behavior. */ }
                if (Out != null) Out.LogInfo("[HListNameCache] " + value);
            }
        }
        private static void Warn(string value)
        {
            lock (Gate) { if (++WarningCount <= 4) Write("WARNING " + value); }
        }
        private static void Summary()
        {
            lock (Gate)
            {
                if (SummaryWritten) return;
                SummaryWritten = true;
                for (int i = 0; i < Targets.Length; i++)
                    Write("SUMMARY " + Targets[i] + " original_calls=" + Miss[i] + " cache_hits=" + Hit[i] +
                        " names=" + (Stored[i] == null ? "NOT_CACHED" : Stored[i].Length.ToString()));
            }
        }
        private void OnApplicationQuit() { Summary(); }
        private void OnDestroy()
        {
            Summary();
            try
            {
                if (_harmony != null)
                {
                    MethodInfo u = _harmony.GetType().GetMethod("UnpatchSelf", Type.EmptyTypes);
                    if (u != null) u.Invoke(_harmony, null);
                }
            }
            catch (Exception ex) { Warn("unpatch " + ex.GetType().Name + " " + ex.Message); }
            lock (Gate) { if (FileOut != null) { FileOut.Flush(); FileOut.Dispose(); FileOut = null; } }
        }
    }
}
