﻿# PowerShell 5.1; fixed successful binary, no recompilation and no overwrite of existing mods.
param([ValidateSet('Install','CollectRemove')][string]$Mode='Install',[string]$GameRoot='F:\illusion\Koikatu')
$ErrorActionPreference='Stop'
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$Id=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$RunDir=Join-Path $Here ('Results\'+$Mode+'_'+$Id)
$ResultZip=Join-Path $Here ('SideloaderHListNameCache_Stable_'+$Mode+'_'+$Id+'.zip')
$Plugin=Join-Path $GameRoot 'BepInEx\plugins\KPlugFixes\SideloaderHListNameCache.dll'
$Pointer=Join-Path (Split-Path -Parent $Plugin) 'SideloaderHListNameCache.output.txt'
$Side=Join-Path $GameRoot 'BepInEx\plugins\KK_BepisPlugins\Sideloader.dll'
$Managed=Join-Path $GameRoot 'Koikatu_Data\Managed\Assembly-CSharp.dll'
$Source=Join-Path $Here 'SideloaderHListNameCache.cs'
$Payload=Join-Path $Here 'SideloaderHListNameCache.dll'
$Active=Join-Path $Here 'StableActive.txt'
$OldActive=Join-Path $Here 'ActiveCache.txt'
$OldDiag=Join-Path $GameRoot 'BepInEx\plugins\KPlugFixes\SideloaderHListDiag.dll'
$ExpectedPayload='17F571ACB7901776F1069C1B218E85EDB67918C50A1CE844837C7DA3616429C4'
$ExpectedSource='D873CC477AF79AD90D69E976095F25E2E1B16F129906EC24D3C0CCA98C93F76D'
$ExpectedSide='A72E28585FF0BC62E13E077BF2E4077BCA5A9D7CA2C41AD43DC8B48E667BBE76'
$ExpectedManaged='0038281CAF8DF48A7903C55DC389642EEEB3F2A9114BD9D68AC11C8AC0396BC5'
$ExitCode=1; $TranscriptOn=$false; $CreatedPlugin=$false; $CreatedPointer=$false; $CreatedActive=$false
function Need([string]$p) { if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw ('Missing: '+$p) } }
function SHA([string]$p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToUpperInvariant() }
function CheckStopped { if (@(Get-Process -Name Koikatu -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Koikatu is running. Exit normally; no process was terminated.' } }
function TextFile([string]$p,[string]$s) { [System.IO.File]::WriteAllText($p,$s,([System.Text.UTF8Encoding]::new($false))) }
function CollectIfExists([string]$src,[string]$dst) { if(Test-Path -LiteralPath $src -PathType Leaf){Copy-Item -LiteralPath $src -Destination (Join-Path $RunDir $dst) -ErrorAction Stop} }
try {
 New-Item -ItemType Directory -Path $RunDir -Force | Out-Null
 Start-Transcript -LiteralPath (Join-Path $RunDir 'Operation.log') | Out-Null; $TranscriptOn=$true
 Write-Host ('Sideloader HListNameCache v0.1.0 TESTED STABLE / '+$Mode)
 CheckStopped; Need $Side; Need $Managed
 if ((SHA $Side) -ne $ExpectedSide) {throw 'Sideloader baseline SHA mismatch. No game changes.'}
 if ((SHA $Managed) -ne $ExpectedManaged) {throw 'Assembly-CSharp baseline SHA mismatch. No game changes.'}
 Write-Host '[OK] Original baseline SHA256 matched (no original DLL will be modified).'
 if($Mode -eq 'Install') {
  Need $Payload; Need $Source
  if((SHA $Payload) -ne $ExpectedPayload){throw 'Frozen DLL SHA256 mismatch.'}
  if((SHA $Source) -ne $ExpectedSource){throw 'Frozen source SHA256 mismatch.'}
  if(Test-Path -LiteralPath $OldDiag){throw 'Old HListDiag is still installed; do not combine diagnostics.'}
  if(Test-Path -LiteralPath $OldActive){throw 'Experimental manifest exists. Use original experimental CollectRemove first.'}
  if(Test-Path -LiteralPath $Active){throw 'StableActive.txt already exists. Refusing duplicate install.'}
  if(Test-Path -LiteralPath $Plugin){throw 'Cache DLL already exists. Refusing overwrite.'}
  if(Test-Path -LiteralPath $Pointer){throw 'Cache output pointer already exists. Refusing overwrite.'}
  $Diag=Join-Path $RunDir 'SideloaderHListNameCache.log'
  $Pending=$Plugin+'.pending_'+$Id
  try {
   Copy-Item -LiteralPath $Payload -Destination $Pending -ErrorAction Stop
   if((SHA $Pending) -ne $ExpectedPayload){throw 'Pending DLL SHA mismatch.'}
   [System.IO.File]::Move($Pending,$Plugin); $CreatedPlugin=$true
  } finally { if(Test-Path -LiteralPath $Pending){Remove-Item -LiteralPath $Pending -Force -ErrorAction SilentlyContinue} }
  if((SHA $Plugin) -ne $ExpectedPayload){throw 'Installed DLL SHA mismatch.'}
  $CreatedPointer=$true
  TextFile $Pointer ($Diag+[Environment]::NewLine)
  $PointerSha=SHA $Pointer
  $manifest=@('FORMAT=SideloaderHListNameCache_Stable_v0.1.0',('GameRoot='+$GameRoot),('Plugin='+$Plugin),('PluginSHA256='+$ExpectedPayload),('Pointer='+$Pointer),('PointerSHA256='+$PointerSha),('SideloaderSHA256='+$ExpectedSide),('AssemblyCSharpSHA256='+$ExpectedManaged),('SourceSHA256='+$ExpectedSource),('PatchLog='+$Diag)) -join [Environment]::NewLine
  $CreatedActive=$true; TextFile $Active ($manifest+[Environment]::NewLine)
  Copy-Item -LiteralPath $Active -Destination (Join-Path $RunDir 'InstallManifest.txt')
  Write-Host '[OK] Exact previously tested DLL installed and hashed. Patch source was not rebuilt.'
  $ExitCode=0
 } else {
  Need $Active
  $e=@{}; foreach($s in [System.IO.File]::ReadAllLines($Active)){ $j=$s.IndexOf('='); if($j -gt 0){$e[$s.Substring(0,$j)]=$s.Substring($j+1)} }
  if($e['FORMAT'] -ne 'SideloaderHListNameCache_Stable_v0.1.0' -or $e['GameRoot'] -ne $GameRoot -or $e['Plugin'] -ne $Plugin -or $e['Pointer'] -ne $Pointer -or $e['PluginSHA256'] -ne $ExpectedPayload -or $e['SideloaderSHA256'] -ne $ExpectedSide -or $e['AssemblyCSharpSHA256'] -ne $ExpectedManaged){throw 'Active manifest mismatch. No deletion.'}
  Need $Plugin; Need $Pointer
  if((SHA $Plugin) -ne $ExpectedPayload -or (SHA $Pointer) -ne $e['PointerSHA256']){throw 'Installed plugin/pointer modified. Refusing to remove.'}
  Copy-Item -LiteralPath $Active -Destination (Join-Path $RunDir 'ActiveManifest.txt')
  CollectIfExists $e['PatchLog'] 'SideloaderHListNameCache.log'
  CollectIfExists (Join-Path $GameRoot 'BepInEx\LogOutput.log') 'LogOutput.log'
  CollectIfExists (Join-Path $GameRoot 'Koikatu_Data\output_log.txt') 'output_log.txt'
  Copy-Item -LiteralPath $Plugin -Destination (Join-Path $RunDir 'SideloaderHListNameCache.dll.installed')
  Copy-Item -LiteralPath $Pointer -Destination (Join-Path $RunDir 'SideloaderHListNameCache.output.txt.installed')
  if((SHA (Join-Path $RunDir 'SideloaderHListNameCache.dll.installed')) -ne $ExpectedPayload -or (SHA (Join-Path $RunDir 'SideloaderHListNameCache.output.txt.installed')) -ne $e['PointerSHA256']) {throw 'Backup hash mismatch; files not removed.'}
  CheckStopped
  try {
   Remove-Item -LiteralPath $Plugin -Force -ErrorAction Stop
   Remove-Item -LiteralPath $Pointer -Force -ErrorAction Stop
   if((Test-Path -LiteralPath $Plugin) -or (Test-Path -LiteralPath $Pointer)){throw 'Partial removal.'}
   Remove-Item -LiteralPath $Active -Force -ErrorAction Stop
  } catch {
   if(-not (Test-Path -LiteralPath $Plugin)){Copy-Item -LiteralPath (Join-Path $RunDir 'SideloaderHListNameCache.dll.installed') -Destination $Plugin -ErrorAction SilentlyContinue}
   if(-not (Test-Path -LiteralPath $Pointer)){Copy-Item -LiteralPath (Join-Path $RunDir 'SideloaderHListNameCache.output.txt.installed') -Destination $Pointer -ErrorAction SilentlyContinue}
   throw
  }
  Write-Host '[OK] Logs collected. Only this stable plugin and pointer removed. Originals unchanged.'
  $ExitCode=0
 }
} catch {
 Write-Host ('[ERROR] '+$_.Exception.Message) -ForegroundColor Red
 if($Mode -eq 'Install') {
  if($CreatedActive -and (Test-Path -LiteralPath $Active)){Remove-Item -LiteralPath $Active -Force -ErrorAction SilentlyContinue}
  if($CreatedPointer -and (Test-Path -LiteralPath $Pointer)){ if((-not $PointerSha) -or ((SHA $Pointer) -eq $PointerSha)){Remove-Item -LiteralPath $Pointer -Force -ErrorAction SilentlyContinue} }
  if($CreatedPlugin -and (Test-Path -LiteralPath $Plugin)){ if((SHA $Plugin) -eq $ExpectedPayload){Remove-Item -LiteralPath $Plugin -Force -ErrorAction SilentlyContinue} }
 }
 Write-Host '[SAFE STOP] Check Operation.log; original game DLLs were not modified.'
 $ExitCode=1
} finally {
 if($TranscriptOn){Stop-Transcript | Out-Null}
 try {Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory($RunDir,$ResultZip);Write-Host ('Result ZIP: '+$ResultZip)}catch{Write-Host ('[WARNING] Could not ZIP result: '+$_.Exception.Message)}
}
exit $ExitCode
