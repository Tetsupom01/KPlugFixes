@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Stable.ps1" -Mode CollectRemove -GameRoot "F:\illusion\Koikatu"
set "RC=%ERRORLEVEL%"
echo.
echo ExitCode=%RC%
pause
exit /b %RC%
