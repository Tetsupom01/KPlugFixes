﻿KPlugNullGuardsFix v0.2.0｜日本語README

【用途】
kPlugの特定のnullや破棄済みオブジェクトに関係する例外を限定的に抑制します。

【対応環境・依存】
既存の検証基準：Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5。
当時の参照kPlug.dll SHA-256：34C13976108DB0A18A7AD6B7CFDA5517B4A9A83D85C9A909820144264C743855
異なる環境での互換性は未検証です。元のkPlug.dllを置き換える指示ではありません。

【導入・更新】
1. Koikatuを終了します。
2. 既存KPlugNullGuardsFix.dllの配置先・SHA-256を確認し、使用中ならバックアップします。
3. このZIPのBepInExフォルダをゲーム本体フォルダへ展開します。
   導入先：BepInEx/plugins/KPlugFixes/KPlugNullGuardsFix.dll
4. 旧plugins直下・plugins/test等、他のフォルダに同名DLLが残っていないか確認してください。二重ロードを避け、不明なファイルを無断削除しないでください。
5. 起動後、BepInEx/LogOutput.logで対象DLLが正常にロードされることを確認します。

【アンインストール・復元】
ゲームを終了して、このZIPで導入した対象DLLだけを外します。旧版が必要ならバックアップから復元してください。

【既知の制約】
旧standalone版KPlugAtHomeDestroyGuardはv0.2.0へ統合済みです。両方を同時に有効化しないでください。全例外の修正ではありません。
元の実機成功DLLを無変更で再梱包しています。新しいZIPの導入動作そのものは実機で未検証です。

【SHA-256】
DLL：DA40FB1DB618BACCB229D36BBE4F557DF499A0F7227B720BD3298090887CD087
旧DLL単体ZIP：650BF318EAFB1B7CBE7C0F7094B7C73D49CAF3E014CA3D5AB0AF89194D803033
新ZIP：GitHubルートのSHA256SUMS.txtに記載。

技術説明：https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/NullGuardsFix/README_ja.md
ソース：https://github.com/Tetsupom01/KPlugFixes/blob/main/src/NullGuardsFix/KPlugNullGuardsFix_v0.2.0.cs
