KPlugNullGuardsFix v0.2.0 | English README

PURPOSE
Adds limited guards against certain null/destroyed-object kPlug exceptions.

ENVIRONMENT / DEPENDENCIES
Existing validated baseline: Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5.
Historical kPlug.dll SHA-256: 34c13976108db0a18a7ad6b7cfda5517b4a9a83d85c9a909820144264c743855
Compatibility with other environments has not been established; do not replace your kPlug.dll based on this value.

INSTALL / UPDATE
1. Fully exit Koikatu.
2. Locate any installed KPlugNullGuardsFix.dll; record its path and SHA-256, then back it up if present.
3. Extract the BepInEx folder from this ZIP into your game root.
   Destination: BepInEx/plugins/KPlugFixes/KPlugNullGuardsFix.dll
4. Check other plugin directories, including plugins/ root and plugins/test/, to avoid duplicate loads. Do not delete unknown files without checking.
5. Launch the game and check BepInEx/LogOutput.log for a successful load.

UNINSTALL / ROLLBACK
Exit the game and remove only the DLL installed by this package. Restore a previous DLL from your backup if needed.

KNOWN LIMITATIONS
The older standalone KPlugAtHomeDestroyGuard is integrated into this release; do not activate both. Not all exceptions are covered.
The previously published runtime-tested DLL is packaged byte-for-byte without modification. The new installer ZIP has not been separately runtime-tested.

SHA-256
DLL: da40fb1db618baccb229d36bbe4f557df499a0f7227b720bd3298090887cd087
Original DLL-only ZIP: 650bf318eafb1b7cbe7c0f7094b7c73d49caf3e014ca3d5ab0af89194d803033
Current ZIP: see the GitHub root SHA256SUMS.txt.

Japanese documentation: https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/NullGuardsFix/README_ja.md
Source: https://github.com/Tetsupom01/KPlugFixes/blob/main/src/NullGuardsFix/KPlugNullGuardsFix_v0.2.0.cs
