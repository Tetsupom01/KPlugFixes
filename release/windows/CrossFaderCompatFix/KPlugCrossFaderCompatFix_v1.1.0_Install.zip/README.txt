KPlugCrossFaderCompatFix v1.1.0 - official release (2026-10-31)
Target: Koikatu 5.1 / kPlug 3.6.0 / CrossFader 0.11 / BepInEx 5.4.23.5

INSTALL:
1. Close Koikatu.
2. Back up any previous KPlugCrossFaderCompatFix.dll.
3. Ensure no other active copy exists under BepInEx/plugins (including test/).
4. Extract this ZIP into the Koikatu game root, retaining folder paths.

File: BepInEx/plugins/KPlugCrossFaderCompatFix.dll
SHA-256: 1F6F359255D3501545F1B97E25DC059436FA24C3EEB704EC9DB93E80256B4154
Source SHA-256: 98627C2243BE4A49AF164F88A5C47891B372A395B586CA8E454130DC79C2EBAC

TEST STATUS:
- Previous v1.1.0 build: HPoint MoveBoundary invalidation observed 3 times
  and user approved its behavior. Its SHA-256 was CF489CCD0E9A3CFC63FF308035ED13272A1ED53D185615B2EC82D8D77EDB67C5.
- This label-clean build: Only two runtime log strings and one source comment
  changed (no gameplay logic changes). BepInEx loaded it and logged:
    [MOVE_BOUNDARY READY] version=1.1.0
    v1.1.0 MoveBoundary active.
- A fresh HPoint motion test of this exact label-clean binary has not been
  separately documented at the release date.

ROLLBACK:
With the game closed, restore your SHA-verified previous working DLL.
Do not activate v1.0.0 and v1.1.0 simultaneously.

Third-party DLLs are NOT included in this archive.
