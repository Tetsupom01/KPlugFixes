﻿【KPlugCrossFaderCompatFix.dll v1.2.0】日本語での導入方法

対応環境・必要なもの：Koikatu 5.1 / kPlug 3.6.0 / CrossFader 0.11 / BepInEx 5.4.23.5
※上記のバージョンを基準環境として動作確認しています。異なる環境での互換性は未確認です。

目的：Hポイント移動後の持続的な姿勢崩れとCrossFader切替競合を軽減します。

導入手順
1. Koikatuを完全に終了する。
2. 既存の同名DLLをバックアップする。
3. このZIPのBepInExフォルダをゲーム本体フォルダに展開する。
4. 配置先：BepInEx/plugins/KPlugFixes/KPlugCrossFaderCompatFix.dll
5. 旧配置先（BepInEx/plugins直下や別フォルダ）の同名DLLを残さない。
   二重配置は競合の原因となるため、古い版の場所を確認する。
6. Koikatu起動後、BepInEx/LogOutput.logで対象DLLのLoadingが1回か確認する。

注意：絶頂後のHポイント移動後、Enter時に一瞬座標がずれることや、Enterが反応しないことがあります。
ゲーム本体・kPlug.dllは配布しません。
DLLは既存の正式版と同一で、ZIP内の配置先と説明文のみ変更しています。
詳細ログ：BepInEx/config/tetsupom.kplug.crossfader.compatfix.cfg で
[Logging] EnableDiagnosticLogs = true とし、再起動します。
通常はfalseです。出力先はBepInEx/KPlugCrossFaderCompatFix.logです。

戻し方：ゲームを終了し、新DLLを外して保存した旧DLLを戻してください。
DLL SHA-256：2392CCAFE5663EFC4FD80F8F72E9741796DE1DDD85D92F9A0E2C0F6C3E45ACFC
https://github.com/Tetsupom01/KPlugFixes
