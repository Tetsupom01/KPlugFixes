KPlugCrossFaderCompatFix.dll v1.2.0 - English installation guide

Tested environment and dependencies: Koikatu 5.1, kPlug 3.6.0, CrossFader 0.11 and BepInEx 5.4.23.5.
Compatibility with other versions is not established.

Purpose: Reduces persistent pose corruption after H-point moves and coordinates animation transitions with CrossFader.

Installation:
1. Exit Koikatu completely.
2. Back up any existing DLL with the same name.
3. Extract the BepInEx folder in this ZIP into the game root.
4. Target: BepInEx/plugins/KPlugFixes/KPlugCrossFaderCompatFix.dll
5. Remove the old copy from the plugins root or another subfolder only after backing it up.
   Avoid loading duplicate copies of the same plugin.
6. Restart and confirm exactly one Loading entry in BepInEx/LogOutput.log.

Known limitations: An intermittent first-Enter coordinate displacement after post-climax H-point moves and occasional Enter nonresponse remain unresolved.
The DLL is byte-identical to the previous official build; only ZIP layout/docs changed.
For diagnostics, set [Logging] EnableDiagnosticLogs = true in the plugin configuration, then restart. The default is false.

Uninstall: Exit the game, remove this DLL and restore your saved previous DLL.
DLL SHA-256: 2392CCAFE5663EFC4FD80F8F72E9741796DE1DDD85D92F9A0E2C0F6C3E45ACFC
https://github.com/Tetsupom01/KPlugFixes
