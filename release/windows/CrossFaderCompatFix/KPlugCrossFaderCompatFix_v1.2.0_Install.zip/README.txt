KPlug CrossFader Compat Fix v1.2.0 — official installer

Contents:
  BepInEx/plugins/KPlugCrossFaderCompatFix.dll
  README.txt

Install:
  Close the game and make a backup of any existing BepInEx/plugins/KPlugCrossFaderCompatFix.dll.
  Extract all contents of this ZIP directly into your Koikatsu game folder; confirm overwriting if appropriate.

Configuration (BepInEx/config/tetsupom.kplug.crossfader.compatfix.cfg):
  [Logging]
  EnableDiagnosticLogs = false

To diagnose ExtraIK suppressions, set to true then restart. CrossFader+ExtraIK entries go to
BepInEx/KPlugCrossFaderCompatFix.log (a single file). Then set false and restart.

Important:
  This stable release improves persistent pose corruption when moving H-points.
  Intermittent first-Enter transient coordinate displacement and occasional Enter nonresponse remain known issues.
  The display labels were changed from the last runtime-tested candidate with no IL modification;
  the exact final label-cleaned binary has not undergone a separate live smoke test.

Version 1.2.0
DLL SHA-256: 2392CCAFE5663EFC4FD80F8F72E9741796DE1DDD85D92F9A0E2C0F6C3E45ACFC
