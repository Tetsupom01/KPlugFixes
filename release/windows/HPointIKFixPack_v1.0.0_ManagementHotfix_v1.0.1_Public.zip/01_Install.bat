@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-FixPack.ps1" -Mode Install
set "rc=%ERRORLEVEL%"
echo.
echo ExitCode=%rc%
pause
exit /b %rc%
