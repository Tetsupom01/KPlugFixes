# HPointIK DeskScoped ExtraIK Guard v0.2.0 RC1 (successful binary frozen)

PURPOSE: Distribute the EXACT successful Windows-built DLL from the 2026-10-17 09:10 session.
Do NOT recompile, rewrite, or edit the DLL/source. The internal BepInEx label still says
EXPERIMENT / v0.2.0. This is intentional: changing the assembly would change its SHA.
RC1 is a release CANDIDATE, not yet a proven long-term production release.

SCOPE: Only inside ChangeAnimator(destination=desk back caress, mode=aibu, file=kha_f_05),
in the Core.HActionBase_PostSetPlay -> CheckOnStateChange -> SetIkTargets(false) path, and
ONLY if the exact old-extra-sonyu-state conditions from original v0.2.0 hold. At most one
original SetIkTargets(false) body is skipped PER eligible destination call. Otherwise
original methods run. All stable Fixes and original game DLLs are untouched.

CONTENT: Successful prebuilt guard DLL (28,672 bytes), EXACT original tested C# source,
validated SHA manifest, prior in-game validation memo, status/install/collect/uninstall scripts.
FlowDiag v0.3.0 is deliberately NOT installed. The guard still writes its modest log
at BepInEx/plugins/KPlugFixes/HPointIKStaleExtraIKGuard.log. Old sessions may be appended;
use the newest SESSION_START when reviewing results.

INSTALL -- full game shutdown first:
  1. Extract the ZIP to a NEW folder. Do not mix with the EXP folder or move after Install.
  2. Run 04_Status.bat. Both original SHA values must be OK, all named experimental/diagnostic
     DLLs must be ABSENT, and RC1 manifests must be False. Otherwise STOP and send Status ZIP.
  3. Run 01_Install.bat ONCE. It verifies exact binary/source SHA and baseline hashes,
     rejects conflicts and existing manifests, checks Harmony 2.9, stages + atomically moves
     the EXACT compiled DLL without rebuilding, then verifies the installed SHA.
  4. Send Results/Install_*.zip (or its Operation.log). Do not reinstall on an error.
  5. After review, start the game and verify [HPointStaleIK] READY v0.2.0. Send startup log.

SHORT RC1 REGRESSION (only after startup log review):
  - Repeat a known problematic route: bed -> missionary 2 -> desk back caress.
  - Also a source-extra route (khs_f_134, khs_f_95, or khs_f_69) -> desk back caress,
    one non-desk transition, and numpad Return to test vanilla transitions.
  - Report any visible arm/hand clipping, transition failure, or new side effects.
  - SUPPRESS_DESK_EXTRA must appear only during the appropriate desk call. If it never appears,
    visual success alone does NOT establish effectiveness.
  - STOP if unexpected serious breakage occurs; use 03_Uninstall.bat after game shutdown.

AFTER TEST -- game fully shut down:
  - Run 02_Collect_Keep.bat. It verifies installed SHA, captures plugin/game logs and DLL,
    and LEAVES RC1 INSTALLED. Send Results/CollectKeep_*.zip.
  - If rollback is needed, run 03_Uninstall.bat instead. It checks exact owned SHA, saves
    + validates a PreUninstall ZIP BEFORE deletion, then removes only RC1 and its own manifests.
    Never delete an unverified or changed DLL automatically.
  - 04_Status.bat can inspect state without altering it.
  - If a script displays [STOP], DO NOT manually edit/replace DLLs; send Results ZIP.

BASELINE kPlug.dll SHA256: 34C13976108DB0A18A7AD6B7CFDA5517B4A9A83D85C9A909820144264C743855
BASELINE Assembly-CSharp.dll SHA256: 0038281CAF8DF48A7903C55DC389642EEEB3F2A9114BD9D68AC11C8AC0396BC5
FROZEN DLL SHA256: F167EF2459C695B4A7B1782141E9640E1C013D00B833D1E48D5B0C54FD4ECC54
ORIGINAL SOURCE SHA256: B9E155DEF6C166FE58ED36E128425092E11AB4BF180F687F63BEA1A5165A6B47
Prior experiment ZIP/SHA and session are recorded in VALIDATION_20261017.md.
Static packaging / SHA checks were performed here. This exact RC1 no-FlowDiag setup has NOT
been run on the user's Windows machine yet; success requires the short regression above.
