﻿param(
    [ValidateSet('Status','Install','CollectKeep','Uninstall')][string]$Mode='Status',
    [string]$GameRoot='F:\illusion\Koikatu'
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$Version='HPointIK_DeskScopedExtraIKGuard_v0.2.0_RC1_Frozen'
$PluginSHA='F167EF2459C695B4A7B1782141E9640E1C013D00B833D1E48D5B0C54FD4ECC54'
$SourceSHA='B9E155DEF6C166FE58ED36E128425092E11AB4BF180F687F63BEA1A5165A6B47'
$ExpectedKPlug='34C13976108DB0A18A7AD6B7CFDA5517B4A9A83D85C9A909820144264C743855'
$ExpectedAssembly='0038281CAF8DF48A7903C55DC389642EEEB3F2A9114BD9D68AC11C8AC0396BC5'
$Base=$PSScriptRoot
$GameRoot=[IO.Path]::GetFullPath($GameRoot)
$Dir=Join-Path $GameRoot 'BepInEx\plugins\KPlugFixes'
$Target=Join-Path $Dir 'HPointIKStaleExtraIKGuard.dll'
$Payload=Join-Path $Base 'HPointIKStaleExtraIKGuard.dll'
$Source=Join-Path $Base 'HPointIKStaleExtraIKGuard.cs'
$Active=Join-Path $Base 'RC1_ActiveInstall.json'
$Backup=Join-Path $Base 'RC1_ActiveInstall.backup.json'
$Results=Join-Path $Base 'Results'
$OtherNames=@('HPointIKTargetFlowDiag.dll','HPointIKTargetRestoreFix.dll','HPointIKPreApplyRestore.dll', 'HPointIKStateBranchDiag.dll','HPointILRuntimeProbe.dll')
function Hash([string]$p) {
    if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw "Missing file: $p"}
    return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToUpperInvariant()
}
function AssertHash([string]$p,[string]$expected,[string]$label){
    $h=Hash $p
    if($h -ne $expected){throw "SHA MISMATCH $label expected=$expected actual=$h path=$p"}
    Write-Host "[OK] $label SHA256=$h"
}
function AssertBaseline {
    AssertHash (Join-Path $GameRoot 'BepInEx\plugins\kPlug\kPlug.dll') $ExpectedKPlug 'kPlug baseline'
    AssertHash (Join-Path $GameRoot 'Koikatu_Data\Managed\Assembly-CSharp.dll') $ExpectedAssembly 'Assembly-CSharp baseline'
}
function AssertClosed {
    if(@(Get-Process -Name 'Koikatu*' -ErrorAction SilentlyContinue).Count -gt 0){throw 'Close Koikatu before Install, CollectKeep or Uninstall.'}
}
function WriteUtf8([string]$p,[string]$v){[IO.File]::WriteAllText($p,$v,(New-Object Text.UTF8Encoding($false)))}
function CopyIf([string]$p,[string]$n,[string]$dest){
    if(Test-Path -LiteralPath $p -PathType Leaf){Copy-Item -LiteralPath $p -Destination (Join-Path $dest $n) -ErrorAction Stop}
}
function CopyLogs([string]$dest){
    CopyIf (Join-Path $Dir 'HPointIKStaleExtraIKGuard.log') 'HPointIKStaleExtraIKGuard.log' $dest
    CopyIf (Join-Path $GameRoot 'BepInEx\LogOutput.log') 'LogOutput.log' $dest
    CopyIf (Join-Path $GameRoot 'output_log.txt') 'output_log_root.txt' $dest
    CopyIf (Join-Path $GameRoot 'Koikatu_Data\output_log.txt') 'output_log_data.txt' $dest
}
function AssertNoConflicts {
    foreach($n in $OtherNames) {
        $p=Join-Path $Dir $n
        if(Test-Path -LiteralPath $p -PathType Leaf){throw "Conflicting diagnostic or experimental DLL present: $p"}
    }
}
function ReadOwned {
    $haveA=Test-Path -LiteralPath $Active -PathType Leaf
    $haveB=Test-Path -LiteralPath $Backup -PathType Leaf
    if(!$haveA -and !$haveB){throw 'No RC1 ownership manifest; refusing action.'}
    $mfile=if($haveA){$Active}else{$Backup}
    $m=Get-Content -LiteralPath $mfile -Raw -Encoding UTF8 | ConvertFrom-Json
    if([string]$m.version -ne $Version -or [string]$m.plugin_sha -ne $PluginSHA -or
       [string]$m.source_sha -ne $SourceSHA -or
       ![string]::Equals([string]$m.game_root,$GameRoot,[StringComparison]::OrdinalIgnoreCase) -or
       ![string]::Equals([string]$m.plugin,$Target,[StringComparison]::OrdinalIgnoreCase)){
        throw 'RC1 manifest identity, path, or SHA mismatch. Refusing action.'
    }
    if($haveA -and $haveB){
        $n=Get-Content -LiteralPath $Backup -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach($f in @('version','game_root','plugin','plugin_sha','source_sha','created')){
           if([string]$n.$f -cne [string]$m.$f){throw "Active/backup manifest mismatch: $f"}
        }
    }
    return $m
}
function CollectFiles([string]$dest){
    CopyLogs $dest
    CopyIf $Target 'HPointIKStaleExtraIKGuard.dll.installed' $dest
    CopyIf $Active 'RC1_ActiveInstall.json' $dest
    CopyIf $Backup 'RC1_ActiveInstall.backup.json' $dest
    $proof="version=$Version`r`nplugin_sha=$PluginSHA`r`nsource_sha=$SourceSHA`r`nkplug_sha=$ExpectedKPlug`r`nassembly_sha=$ExpectedAssembly`r`n"
    WriteUtf8 (Join-Path $dest 'FrozenHashes.txt') $proof
}
function AssertArchive([string]$zip,[string[]]$required){
    if(!(Test-Path -LiteralPath $zip -PathType Leaf) -or (Get-Item -LiteralPath $zip).Length -lt 1000){throw 'Evidence archive absent or too small.'}
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z=[IO.Compression.ZipFile]::OpenRead($zip)
    try{
        $entries=@($z.Entries | ForEach-Object {$_.Name})
        foreach($n in $required){if($entries -notcontains $n){throw "Missing ZIP evidence entry: $n"}}
        foreach($e in $z.Entries) {
            if($e.Length -gt 0) {
                $stream=$e.Open()
                try {
                    $buffer=New-Object byte[] 65536
                    $readTotal=[long]0
                    while(($count=$stream.Read($buffer,0,$buffer.Length)) -gt 0){$readTotal += $count}
                    if($readTotal -ne $e.Length){throw "ZIP extraction length mismatch: $($e.Name)"}
                }finally{$stream.Dispose()}
            }
        }
    }finally{$z.Dispose()}
    Write-Host "[OK] Evidence ZIP checked SHA256=$(Hash $zip)"
}
New-Item -ItemType Directory -Path $Results -Force | Out-Null
$stamp=(Get-Date).ToString('yyyyMMdd_HHmmss_fff')
$r=Join-Path $Results ($Mode+'_'+$stamp)
New-Item -ItemType Directory -Path $r -ErrorAction Stop | Out-Null
$transcript=$false; $ok=$false
try {
    Start-Transcript -LiteralPath (Join-Path $r 'Operation.log') -ErrorAction Stop | Out-Null
    $transcript=$true
    Write-Host "=== $Version Mode=$Mode GameRoot=$GameRoot ==="
    AssertBaseline
    AssertHash $Payload $PluginSHA 'FROZEN tested RC1 payload'
    AssertHash $Source $SourceSHA 'FROZEN original v0.2.0 EXP source'
    if($Mode -eq 'Status') {
        foreach($p in (@($Target)+@($OtherNames|ForEach-Object{Join-Path $Dir $_}))){
            if(Test-Path -LiteralPath $p -PathType Leaf){Write-Host "PRESENT $p SHA256=$(Hash $p)"}
            else{Write-Host "ABSENT $p"}
        }
        Write-Host "ActiveManifest=$([bool](Test-Path -LiteralPath $Active -PathType Leaf)) BackupManifest=$([bool](Test-Path -LiteralPath $Backup -PathType Leaf))"
        CopyLogs $r
        $ok=$true
    } elseif($Mode -eq 'Install') {
        AssertClosed
        if(Test-Path -LiteralPath $Target -PathType Leaf){throw 'A guard DLL is already installed. Never overwrite it.'}
        AssertNoConflicts
        if((Test-Path -LiteralPath $Active -PathType Leaf) -or (Test-Path -LiteralPath $Backup -PathType Leaf)){throw 'An RC1 manifest already exists. Run Status first.'}
        $harmonyDll=Join-Path $GameRoot 'BepInEx\core\0Harmony.dll'
        $bepDll=Join-Path $GameRoot 'BepInEx\core\BepInEx.dll'
        foreach($p in @($harmonyDll,$bepDll)){if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw "Missing runtime dependency: $p"}}
        $hv=[Reflection.AssemblyName]::GetAssemblyName($harmonyDll).Version
        if($hv.Major -ne 2 -or $hv.Minor -ne 9){throw "Expected validated Harmony 2.9.x, actual=$hv"}
        Write-Host "[OK] Harmony version=$hv"
        $manifest=[ordered]@{version=$Version;game_root=$GameRoot;plugin=$Target;plugin_sha=$PluginSHA;source_sha=$SourceSHA;created=(Get-Date).ToString('o')}
        $j=$manifest|ConvertTo-Json -Depth 4
        WriteUtf8 (Join-Path $r 'InstallManifest.json') $j
        $stage=Join-Path $Dir '.HPointIKDeskScopedRC1.staging.dll'
        if(Test-Path -LiteralPath $stage -PathType Leaf){throw "An old staging DLL is present, refusing overwrite: $stage"}
        $unsafe=$false
        $movedByThisInstall=$false
        try {
            New-Item -ItemType Directory -Path $Dir -Force | Out-Null
            # Claim ownership before the first write in the game folder.
            WriteUtf8 $Active $j
            WriteUtf8 $Backup $j
            Copy-Item -LiteralPath $Payload -Destination $stage -ErrorAction Stop
            AssertHash $stage $PluginSHA 'Staged frozen DLL'
            if(Test-Path -LiteralPath $Target -PathType Leaf){throw 'Target appeared during staging; refusing overwrite.'}
            [IO.File]::Move($stage,$Target)  # Atomic rename within target directory; never overwrite.
            $movedByThisInstall=$true
            AssertHash $Target $PluginSHA 'Installed exact tested RC1 DLL'
        } catch {
            $installError=$_
            # Never delete a target that appeared independently before our atomic move.
            if(Test-Path -LiteralPath $stage -PathType Leaf){
                if((Hash $stage) -eq $PluginSHA){Remove-Item -LiteralPath $stage -Force -ErrorAction Stop}
                else{$unsafe=$true;Write-Host "[STOP] Unknown/partial staging file preserved: $stage"}
            }
            if($movedByThisInstall -and (Test-Path -LiteralPath $Target -PathType Leaf)){
                if((Hash $Target) -eq $PluginSHA){Remove-Item -LiteralPath $Target -Force -ErrorAction Stop}
                else{$unsafe=$true;Write-Host "[STOP] Unknown/partial target preserved: $Target"}
            } elseif(Test-Path -LiteralPath $Target -PathType Leaf){
                $unsafe=$true
                Write-Host "[STOP] Target appeared independently, preserved: $Target"
            }
            if(!$unsafe){foreach($p in @($Active,$Backup)){if(Test-Path -LiteralPath $p -PathType Leaf){Remove-Item -LiteralPath $p -Force}}}
            else{Write-Host '[STOP] Ownership manifest retained. Do not rerun Install.'}
            throw $installError
        }
        Write-Host '[OK] Exact successful EXP v0.2.0 binary installed as RC1. No rebuild; no FlowDiag installed.'
        Write-Host '[NOTE] Internal plugin ID/name and EXP marker are unchanged to preserve successful binary SHA.'
        Write-Host '[NOTE] Verify [HPointStaleIK] READY v0.2.0 before H operations.'
        $ok=$true
    } elseif($Mode -eq 'CollectKeep') {
        AssertClosed
        $m=ReadOwned
        AssertHash $Target $PluginSHA 'Owned installed RC1 DLL'
        CollectFiles $r
        AssertHash (Join-Path $r 'HPointIKStaleExtraIKGuard.dll.installed') $PluginSHA 'Collected RC1 DLL'
        Write-Host '[OK] RC1 remains INSTALLED and unchanged; results collected only.'
        $ok=$true
    } elseif($Mode -eq 'Uninstall') {
        AssertClosed
        $m=ReadOwned
        if(!(Test-Path -LiteralPath $Target -PathType Leaf)){throw 'Owned DLL already missing; refusing automatic manifest cleanup. Send Status.'}
        AssertHash $Target $PluginSHA 'Owned RC1 before uninstall'
        CollectFiles $r
        AssertHash (Join-Path $r 'HPointIKStaleExtraIKGuard.dll.installed') $PluginSHA 'Saved owned RC1 copy'
        $pre=Join-Path $Results ('PreUninstall_'+$stamp+'.zip')
        $saveFiles=@(Get-ChildItem -LiteralPath $r -File | Where-Object {$_.Name -ne 'Operation.log'} | ForEach-Object {$_.FullName})
        if($saveFiles.Count -lt 4){throw 'Not enough saved uninstall evidence; refusing deletion.'}
        Compress-Archive -LiteralPath $saveFiles -DestinationPath $pre -CompressionLevel Optimal -ErrorAction Stop
        AssertArchive $pre @('HPointIKStaleExtraIKGuard.dll.installed','RC1_ActiveInstall.json','RC1_ActiveInstall.backup.json','FrozenHashes.txt')
        Remove-Item -LiteralPath $Target -Force -ErrorAction Stop
        if(Test-Path -LiteralPath $Target -PathType Leaf){throw 'RC1 target still present after delete; ownership manifests retained.'}
        foreach($p in @($Active,$Backup)){if(Test-Path -LiteralPath $p -PathType Leaf){Remove-Item -LiteralPath $p -Force -ErrorAction Stop}}
        AssertBaseline
        Write-Host '[OK] RC1 removed. Original game DLLs and all stable fixes untouched.'
        $ok=$true
    }
} catch {
    Write-Host ('[STOP] '+$_.Exception.Message) -ForegroundColor Red
    WriteUtf8 (Join-Path $r 'ERROR.txt') ($_|Out-String)
} finally {
    if($transcript){try{Stop-Transcript|Out-Null}catch{}}
    $zip=$r+'.zip'
    try{
        $items=@(Get-ChildItem -LiteralPath $r -File|ForEach-Object{$_.FullName})
        if($items.Count -gt 0){Compress-Archive -LiteralPath $items -DestinationPath $zip -CompressionLevel Optimal -ErrorAction Stop;Write-Host "[ZIP] $zip SHA256=$(Hash $zip)"}
    }catch{Write-Host ('[WARN] ZIP packaging failed, folder retained: '+$_.Exception.Message)}
    Write-Host "Results=$r"
    if($ok){Write-Host 'ExitCode=0';exit 0}else{Write-Host 'ExitCode=1';exit 1}
}
