@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-HPointDeskScopedRC1.ps1" -Mode Status
set "RC=%ERRORLEVEL%"
echo.
echo Results are next to these BAT files, under Results.
pause
exit /b %RC%
