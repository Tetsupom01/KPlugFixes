# HPointIK DeskScoped ExtraIK Guard v0.2.0 EXP｜実機検証結果

検証日：2026-10-17　状態：**実機で有効性を支持。実験版として成功候補（本番固定は未実施）**

## 目的と変更範囲
机バック愛撫への `HSceneProc.ChangeAnimator` 実行範囲で、旧挿入モーションの追加IK判定が残った状態から `HActionBase_PostSetPlay → ExtraAnimManager.CheckOnStateChange → SetIkTargets(false)` が呼ばれる場合に限り、その `SetIkTargets(false)` 本体を1回抑止する。机以外、判定条件外では元処理を維持。前回v0.1.0の「机に移る前に全体1回限りの抑止を消費する」欠陥を解消。診断用FlowDiag v0.3.0を同梱。

## 入力資料
- `CollectRemove_20261017_091732_715.zip`：ZIP構造テストOK、SHA-256 `DB460ECFD933A3FF00AA2881A27A0945571548BD1F69806322FCEC404E2C1C02`
- `HPointIKStaleExtraIKGuard.log` の**09:10:29開始**のv0.2.0セッションだけを集計。ファイル冒頭には旧v0.1.0（08:40開始）も追記されているので混同しない。
- `HPointIKTargetFlowDiag.log` の**09:10:25開始**のセッションだけを集計。こちらも追記ログ。
- ユーザーの実機報告：「何回か移動したけど今回は崩れなかった」

## 実測結果

| 机 `ChangeAnimator` 時刻 | 移動元 | Checkの判定 | 抑止 |
|---|---|---|---|
| 09:12:32 | 押し付けバック `khs_f_n28` | `extraContains=False` | なし・元処理維持 |
| 09:12:49 | 机バック愛撫 `kha_f_05` | `extraContains=False` | なし・元処理維持 |
| 09:13:35 | 机バック `khs_f_134` | true、旧`InsertIdle`→新`Idle` | `SUPPRESS_DESK_EXTRA` #1（09:13:36.845） |
| 09:15:01 | 後背位 `khs_f_95` | true、旧`InsertIdle`→新`Idle` | `SUPPRESS_DESK_EXTRA` #2（09:15:03.178） |
| 09:15:17 | 机バック愛撫 `kha_f_05` | `extraContains=False` | なし・元処理維持 |
| 09:16:29 | 後背位 `khs_f_69` | true、旧`Insert`→新`Idle` | `SUPPRESS_DESK_EXTRA` #3（09:16:31.046） |

最終集計 `animatorCalls=18 deskCalls=6 checks=6 suppressed=3 passed=0 errors=0`。`passed=0`は条件該当の未抑止がないというこの診断のカウンターであり、すべての非対象処理がブロックされた意味ではない。机以外を含め18回のAnimator呼出あり。

FlowDiagの同セッションは **F7×6、F8×0**。09:13:39、09:15:06、09:16:33の抑止後F7マーカーにおける女性左右手TargetのYは、いずれも左0.6735m・右0.6722m（以前の正常時と一致）。09:15:02には標準の机用 `kha_f_05` 読込を記録。09:16:30にも机用読込のCALLER_TRACEあり。今回のFlowDiagにはイベント詳細がない時間帯もあるため、全ケースで全IK読込を完全記録できたとまでは断定しない。F7はユーザーマーカーであり自動的な修復操作ではない。

## 判定と未確定点
- **実機確認済み：** 対象移動を含む複数回の移動で目立った姿勢崩れなし。旧`khs_f_134`だけでなく`khs_f_95`・`khs_f_69`でも机移動中に抑止が発火した。手Targetは抑止後の観測で正常値。
- **強く支持される原因：** 移動先が机バック愛撫の状態で旧挿入モーション由来の追加IKを重ねることが、机上での異常姿勢に寄与している。
- **留保：** 有限回の実機成功であり、他Hポイント・長時間・キャラ差・別状態での副作用は未検証。実験版を本番成功版へ自動昇格させない。別の崩れ方もすべて解消したとは断定しない。

## 元ファイルと配置物の同一性
- kPlug.dll baseline SHA-256 `34C13976108DB0A18A7AD6B7CFDA5517B4A9A83D85C9A909820144264C743855`：Install/CollectRemoveで一致。
- Assembly-CSharp.dll baseline SHA-256 `0038281CAF8DF48A7903C55DC389642EEEB3F2A9114BD9D68AC11C8AC0396BC5`：一致。
- ソースSHA-256 `B9E155DEF6C166FE58ED36E128425092E11AB4BF180F687F63BEA1A5165A6B47`
- Windows実ビルドされた実験DLL SHA-256 `F167EF2459C695B4A7B1782141E9640E1C013D00B833D1E48D5B0C54FD4ECC54`（回収ZIP内 `.installed` も一致）。
- FlowDiag DLL SHA-256 `97615DFE43A1276DC75F16838FE55DFA2517CC35F0FCBC84F890D2A3FD7F2373`。
- CollectRemoveログ：`PreRemoval`保存後、両実験DLLの所有SHA照合と削除成功、元DLL再照合成功。**現在実験DLL/FlowDiagとも未配置。** 成功済みFixは変更なし。

## 次工程
このv0.2.0のソース・生成DLL・条件・成功時のログを上書きせず保存。既存Fixと独立したパッチとして、実験で観測した条件を維持した本番候補を設計する。抑止範囲を他Hポイントへ無根拠に拡張しない。必要なら本番候補の同一条件で短い回帰テストを1回実施し、元の標準動作・Return遷移・ほかのHポイントを壊していないことを確認して固定する。
