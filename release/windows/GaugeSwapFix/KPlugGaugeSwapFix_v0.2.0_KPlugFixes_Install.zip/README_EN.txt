KPlugGaugeSwapFix v0.2.0 | English README

PURPOSE
Preserves the swapped Main girl's Face/Gauge across H-category or animation changes.

ENVIRONMENT / DEPENDENCIES
Existing validated baseline: Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5.
Historical kPlug.dll SHA-256: 34c13976108db0a18a7ad6b7cfda5517b4a9a83d85c9a909820144264c743855
Compatibility with other environments has not been established; do not replace your kPlug.dll based on this value.

INSTALL / UPDATE
1. Fully exit Koikatu.
2. Locate any installed KPlugGaugeSwapFix.dll; record its path and SHA-256, then back it up if present.
3. Extract the BepInEx folder from this ZIP into your game root.
   Destination: BepInEx/plugins/KPlugFixes/KPlugGaugeSwapFix.dll
4. Check other plugin directories, including plugins/ root and plugins/test/, to avoid duplicate loads. Do not delete unknown files without checking.
5. Launch the game and check BepInEx/LogOutput.log for a successful load.

UNINSTALL / ROLLBACK
Exit the game and remove only the DLL installed by this package. Restore a previous DLL from your backup if needed.

KNOWN LIMITATIONS
Targets the Main-girl swap case only; normal non-swap H scenes are unaffected.
The previously published runtime-tested DLL is packaged byte-for-byte without modification. The new installer ZIP has not been separately runtime-tested.

SHA-256
DLL: 7039f65e09ff3de19b56a1c152a3156b147bf17b70e817862fde5a1684ee8cc9
Original DLL-only ZIP: 7bae97d1a68ead58cba5a467fd44708ae0021a8102f9801c981e7bf0dd21c77b
Current ZIP: see the GitHub root SHA256SUMS.txt.

Japanese documentation: https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/GaugeSwapFix/README_ja.md
Source: https://github.com/Tetsupom01/KPlugFixes/blob/main/src/GaugeSwapFix/KPlugGaugeSwapFix_v0.2.0.cs
