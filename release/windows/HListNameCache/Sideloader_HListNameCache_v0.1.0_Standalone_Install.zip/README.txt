Sideloader HList Name Cache v0.1.0｜導入手順（独立配置版）

【機能】
KoikatuのH体位リストで、対象6アセットの名前一覧の反復取得をキャッシュします。
kPlug固有の不具合修正ではなく、kPlugのAPIを直接使用しません。

【対応環境】
Koikatu 5.1、BepInEx・Harmony。確認環境にはkPlug 3.6.0、Sideloaderが含まれます。
kPlugなしの環境での動作は未確認です。

【導入】
1. Koikatuを終了してください。
2. BepInEx/plugins/以下にSideloaderHListNameCache.dllがないか確認してください。
3. 既存DLLをバックアップして旧配置から取り外してください。
   特に BepInEx/plugins/KPlugFixes/SideloaderHListNameCache.dll を同時に残さないでください。
4. このZIPをKoikatuのゲーム本体フォルダーへ展開してください。
   配置先：BepInEx/plugins/SideloaderHListNameCache.dll
5. 起動ログに以下が出ることを確認し、H体位一覧の表示・選択、Hポイント移動を確認してください。
   Loading [Sideloader H List Name Cache 0.1.0]
   [HListNameCache] PATCH_OK

【解除・復元】
ゲームを終了し、導入したDLLだけを外してください。必要な場合はバックアップを戻します。
他のプラグイン・ゲーム本体ファイルは変更しないでください。

【検証範囲と制限】
DLL本体は従来の実機成功版と同一です。plugins直下への移動後の正常動作は利用者が確認済みです。
ただし、この配布ZIPをゲームルートから展開する一連の操作は別途実機検証していません。
ゲーム起動ログの原本は公開作業時に独立照合していません。
本プラグインはHポイント移動後の姿勢崩れを修正するものではありません。

DLL SHA-256：17F571ACB7901776F1069C1B218E85EDB67918C50A1CE844837C7DA3616429C4
