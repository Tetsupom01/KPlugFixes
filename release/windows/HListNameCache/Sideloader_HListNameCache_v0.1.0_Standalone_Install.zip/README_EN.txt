Sideloader HList Name Cache v0.1.0 — Standalone installation

FUNCTION
Caches repeated asset-name list retrieval for six selected Koikatu H-list bundles.
It does not directly call kPlug APIs and is not a kPlug bug fix.

REQUIREMENTS
Koikatu 5.1, BepInEx and Harmony. The tested environment includes kPlug 3.6.0 and Sideloader.
Operation without kPlug has not been tested.

INSTALLATION
1. Exit Koikatu.
2. Locate any existing SideloaderHListNameCache.dll under BepInEx/plugins/.
3. Back up and remove existing copies before installing.
   In particular, do not keep BepInEx/plugins/KPlugFixes/SideloaderHListNameCache.dll active.
4. Extract this ZIP into the Koikatu game root.
   Destination: BepInEx/plugins/SideloaderHListNameCache.dll
5. Check the startup log, then check H-list display, selection and H-point moves:
   Loading [Sideloader H List Name Cache 0.1.0]
   [HListNameCache] PATCH_OK

REMOVAL
Exit Koikatu and remove only this DLL. Restore a backup if required.
Do not modify unrelated plugins or original game files.

VALIDATION AND LIMITATIONS
The runtime DLL is byte-identical to the previously validated build.
Normal operation after manually relocating it to the plugins root was confirmed by the user.
The installation process of extracting this specific ZIP has not been separately tested.
Original startup logs were not independently inspected for this release update.
This plugin does not fix the separate H-point posture issue.

DLL SHA-256: 17F571ACB7901776F1069C1B218E85EDB67918C50A1CE844837C7DA3616429C4
