Sideloader HList Name Cache v0.1.0 | English README

PURPOSE / CATEGORY
Independent BepInEx/Harmony performance optimization for repeated H-list asset-name enumeration in Koikatu. It does not patch kPlug.dll. Only six exact abdata/h/list bundles are cached: hs2suite, mmbath, mmhouse01, poolmap, purpleroom, sakuraroom.

TESTED ENVIRONMENT AND DEPENDENCIES
Runtime-tested with Koikatu 5.1, kPlug 3.6.0, BepInEx 5.4.23.5 and Sideloader in the original environment. Operation without kPlug or with other configurations has NOT been verified. No third-party DLLs (game, Sideloader.dll, Assembly-CSharp.dll, etc.) are included.

INSTALL / UPDATE
1. Fully exit Koikatu.
2. Locate any existing SideloaderHListNameCache.dll in BepInEx/plugins, record its path and SHA-256, and back it up. If the identical tested DLL is already installed, replacement is unnecessary.
3. Extract the BepInEx folder from this ZIP into the game root.
   Destination: BepInEx/plugins/KPlugFixes/SideloaderHListNameCache.dll
4. Do not leave duplicate copies under other plugins folders. Do not delete unknown files blindly.
5. Check BepInEx/LogOutput.log for "Loading [Sideloader H List Name Cache 0.1.0]" and "[HListNameCache] PATCH_OK", and verify that H lists can be displayed and selected.

UNINSTALL / ROLLBACK
Exit Koikatu and remove only the DLL installed by this ZIP. Restore a previously backed-up version if needed.

VALIDATION / LIMITATIONS
Two real-game sessions on 2026-10-12 recorded 852 and 480 cache hits per targeted bundle, respectively, with normal H controls, pose-list selection and H-point movement. No game-wide FPS or loading-time improvement was quantified; the separate intermittent HPointMove pose issue is not fixed by this plugin.
The DLL payload in this ZIP is byte-identical to the runtime-tested DLL in the archived frozen release. The new ZIP layout has NOT been separately installed or tested in-game.
The old frozen ZIP includes source code and installer/removal scripts and is retained unchanged. Do not install both packages together.

SHA-256
DLL: 17f571acb7901776f1069c1b218e85edb67918c50a1ce844837c7da3616429c4
Original frozen ZIP: 2cf2ba5af6602e49ee8bdc8dffe8197c0e3e500c31911ce2b95b98864b8195bc
New installer ZIP: see root SHA256SUMS.txt on GitHub.

Technical documentation (Japanese): https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/HListNameCache/README_ja.md
Historical frozen package including source: https://github.com/Tetsupom01/KPlugFixes/blob/main/release/windows/HListNameCache/Sideloader_HListNameCache_v0.1.0_Stable_Frozen.zip
