﻿Sideloader HList Name Cache v0.1.0｜日本語README

【用途と区分】
KoikatuのH体位一覧に関係するアセット名一覧の反復取得をキャッシュする、独立したBepInEx/Harmony最適化プラグインです。kPlug.dll自体を修正するパッチではありません。6つの特定のh/listバンドルだけを対象とします（hs2suite、mmbath、mmhouse01、poolmap、purpleroom、sakuraroom）。

【検証済み環境と依存物】
Koikatu 5.1 + kPlug 3.6.0 + BepInEx 5.4.23.5 + Sideloaderを使用する既存環境で実機成功を確認。kPlugなしの環境や他の構成での動作は未検証です。ゲーム本体、Sideloader.dll、Assembly-CSharp.dll等の第三者DLLは同梱しません。

【導入方法】
1. Koikatuを完全終了します。
2. BepInEx/plugins配下を検索し、既存のSideloaderHListNameCache.dllがあれば場所とSHA-256を控え、変更前に保全します。同一SHA-256の成功版が既にあれば交換は不要です。
3. このZIPのBepInExフォルダをゲーム本体フォルダへ展開します。
   配置先：BepInEx/plugins/KPlugFixes/SideloaderHListNameCache.dll
4. 他のpluginsサブフォルダに同名DLLを残して二重ロードしないよう確認してください。不明なファイルを無断削除しないでください。
5. 起動後BepInEx/LogOutput.logで「Loading [Sideloader H List Name Cache 0.1.0]」と「[HListNameCache] PATCH_OK」の記録を確認し、H体位一覧の表示・選択も確認します。

【削除・復元】
ゲームを終了し、今回導入したSideloaderHListNameCache.dllだけを取り外します。以前の版に戻す必要があれば保全した原本を復元します。

【検証状況と制約】
2026-10-12の2回の実機テストで対象6バンドルごとに852回／480回のキャッシュヒットを記録し、H操作・体位一覧・Hポイント移動の正常動作を確認しました。測定したのは取得回数であり、ゲーム全体の速度改善量ではありません。HPoint移動時の姿勢崩れは別問題です。
このZIPは成功済みDLLを一切改変せず配布フォルダ構成だけを変更したものです。新ZIPの実機展開・起動は未検証です。
旧凍結ZIPは、ソース・専用インストール／回収スクリプト等を含む保全パッケージとして残しています。新ZIPとは別物であり、重ねて導入しないでください。

【SHA-256】
DLL: 17F571ACB7901776F1069C1B218E85EDB67918C50A1CE844837C7DA3616429C4
旧凍結ZIP: 2CF2BA5AF6602E49EE8BDC8DFFE8197C0E3E500C31911CE2B95B98864B8195BC
新ZIPのSHA-256: GitHubルートのSHA256SUMS.txtを参照。

日本語技術説明: https://github.com/Tetsupom01/KPlugFixes/blob/main/docs/HListNameCache/README_ja.md
旧凍結版とソース: https://github.com/Tetsupom01/KPlugFixes/blob/main/release/windows/HListNameCache/Sideloader_HListNameCache_v0.1.0_Stable_Frozen.zip
