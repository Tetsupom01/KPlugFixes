KPlugBenchEnterFix v1.0.0 — Official Installation Package

Purpose: BepInEx/Harmony plugin for Koikatu with kPlug 3.6.0. Adjusts Numpad Enter behavior in the bench oral service animation: native idle start, single qualifying emission request above 70% gauge, suppression of invalid/redundant Enter inputs, and transition from the post-emission oral selection. It does not modify the game or kPlug DLLs.

Tested environment: Koikatu 5.1, kPlug 3.6.0, BepInEx 5.4.23.5, Unity 5.6.2f1. Exact reference DLL hashes are in MANIFEST.json; compatibility with other versions is unverified.

Installation:
1. Exit the game completely.
2. Confirm no older HPointBenchEnterPistonGateTrial.dll remains in BepInEx/plugins or plugins/test. Do not load old and new versions together.
3. Extract this ZIP to the Koikatu game root, preserving its directory structure.
   File: BepInEx/plugins/KPlugFixes/KPlugBenchEnterFix.dll
4. Start the game. The runtime log is BepInEx/KPlugBenchEnterFix.log. Check for the READY hooks line.

Removal: Exit the game and delete ONLY BepInEx/plugins/KPlugFixes/KPlugBenchEnterFix.dll. Do not remove other plugins or settings.

Validation: The exact DLL included here was compiled and run on Windows on 2026-11-22. Logs confirm initial and return-to-bench idle starts, accepting an emission request above 70%, blocking low-gauge and redundant inputs, reaching Oral_Idle, and accepting Enter there. The user reported no apparent issue during the test. Visual and audio effects were not automatically measured, and exhaustive compatibility testing was not done.

Known separate limitation: Switching from a later oral animation to the bench animation can fail; this was also reproduced with an earlier Enter test DLL removed. The underlying cause has not been established. This plugin does not change the H-point category routing.

Plugin ID: tetsupom.kplug.benchenterfix
Version: 1.0.0
Exact tested DLL SHA-256: DF1E541CA58B07D2CCCE1A87925BCAB4651E1C2C7DF24A45DB2CFBF29CE0C4CC

Project repository: https://github.com/Tetsupom01/KPlugFixes
This package contains the formally adopted, runtime-tested binary.
