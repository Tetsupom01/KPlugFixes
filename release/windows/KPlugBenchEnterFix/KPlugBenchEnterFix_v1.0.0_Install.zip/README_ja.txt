KPlugBenchEnterFix v1.0.0 — 正式導入版

■ 概要
Koikatu + kPlug 3.6.0向けのBepInEx/Harmonyプラグインです。
ベンチフェラのテンキーEnterに関し、待機中の開始、ゲージ70%超の射精要求、無効入力・連打の遮断、口内選択後の挿入への移行を補正します。
kPlug本体やゲーム本体のDLLは書き換えません。既存のHPointBenchRouteFixとは別のプラグインです。

■ 対応・依存条件（実機検証に使用した構成）
Koikatu 5.1 / kPlug 3.6.0 / BepInEx 5.4.23.5 / Unity 5.6.2f1
検証時の入力ファイルのSHA-256はMANIFEST.jsonに記載。別の版への互換性は未検証です。

■ インストール
1. Koikatuを完全に終了します。
2. 旧検証用DLL（HPointBenchEnterPistonGateTrial.dll）が BepInEx/plugins または plugins/test 以下に残っていないことを確認します。新旧の二重ロードは禁止です。
3. このZIPをKoikatuのゲームルートへ展開し、フォルダー構成を保って配置します。
   配置先: BepInEx/plugins/KPlugFixes/KPlugBenchEnterFix.dll
4. ゲームを起動します。専用ログ: BepInEx/KPlugBenchEnterFix.log
   起動成功の判定には「READY hooks=...」行を使用します。ロード行だけでは成功とはみなしません。

■ アンインストール
ゲーム終了後、BepInEx/plugins/KPlugFixes/KPlugBenchEnterFix.dll のみを削除します。
他のKPlugFixes内のDLLや設定、kPlug本体には触れないでください。

■ 確認済みと未確認
2026-11-22の実機試験では、初回・再移動後の待機中EnterからWLoopへの移行、70%超の射精要求、射精中や70%未満の追加Enterの遮断、Oral_Idleへの遷移、口内選択でのEnter受付をログで確認しました。ユーザーの画面・音声評価も概ね正常です。
ただし、全モーション・全条件の網羅検証や効果音の回数の機械計測は未実施です。

■ 既知の未解決事項
後段の口モーションからベンチフェラへのHポイント再移動に失敗する事象があります。この事象は以前のEnter試験DLLを撤去した状態でも再現しました。原因は未確定であり、本パッチは当該移動経路を修正しません。

■ 固定バイナリ
Runtime Version: 1.0.0
Plugin ID: tetsupom.kplug.benchenterfix
DLL SHA-256: DF1E541CA58B07D2CCCE1A87925BCAB4651E1C2C7DF24A45DB2CFBF29CE0C4CC
検証時と同一DLLを再ビルドせず収録しています。

公開元: https://github.com/Tetsupom01/KPlugFixes
この導入ZIPは実機検証済みの正式採用バイナリです。
