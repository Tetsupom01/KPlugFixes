param([string]$GameRoot = 'F:\illusion\Koikatu')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$out=Join-Path $root 'BuildOutput'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$log=Join-Path $out 'Build.log'
try {
  $source=Join-Path $root 'KPlugCrossFaderCompatFix_v1.2.0.cs'
  $game=[IO.Path]::GetFullPath($GameRoot)
  $managed=Join-Path $game 'Koikatu_Data\Managed'
  $core=Join-Path $game 'BepInEx\core'
  $csc=@('C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe','C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe') | Where-Object {Test-Path $_} | Select-Object -First 1
  if(!$csc){throw 'C# compiler not found'}
  $refs=@((Join-Path $managed 'mscorlib.dll'),(Join-Path $managed 'UnityEngine.dll'),(Join-Path $managed 'Assembly-CSharp.dll'),(Join-Path $core 'BepInEx.dll'),(Join-Path $core '0Harmony.dll'))
  foreach($f in @($source)+$refs){if(!(Test-Path -LiteralPath $f)){throw "Missing reference: $f"}}
  $expected=@{'Assembly-CSharp.dll'='0038281CAF8DF48A7903C55DC389642EEEB3F2A9114BD9D68AC11C8AC0396BC5';'mscorlib.dll'='37E0D42A56EFF62CB3227F3BF1C9CE526D7C33F96FD2027854916468803C1154';'UnityEngine.dll'='771CCA9499B7EB451A6715AD3F6B08486821E85A3824022CB725D68CE3B8BC03';'BepInEx.dll'='8255B28902886085C578B9E427D3073C97002DB85176D2090CDEDA90EF14CE70';'0Harmony.dll'='1A21CC03424FC82C3DD1346905D16494536B9595AE4162228D99FB7C285C1031'}
  foreach($f in $refs){$h=(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash; if($h -ne $expected[[IO.Path]::GetFileName($f)]){throw "Reference SHA mismatch: $f"}}
  $asm=[Reflection.Assembly]::ReflectionOnlyLoadFrom($refs[0]); if($asm.GetName().Version.Major -ne 2){throw 'CLR2 mscorlib required'}
  $dll=Join-Path $out 'KPlugCrossFaderCompatFix_OUT_A_Insert_TRIAL.dll'
  $args=@('/nologo','/target:library','/nostdlib+','/optimize+',('/out:{0}' -f $dll))+@($refs | ForEach-Object { '/reference:{0}' -f $_ })+@($source)
  & $csc @args 2>&1 | Out-File -LiteralPath $log -Encoding UTF8
  if($LASTEXITCODE -ne 0 -or !(Test-Path $dll)){throw "Build failed: see $log"}
  $hash=(Get-FileHash $dll -Algorithm SHA256).Hash
  @("STATUS=BUILD_ONLY_OK","SourceSHA=$((Get-FileHash $source -Algorithm SHA256).Hash)","DLLSHA=$hash","GameRoot=$game","NO_GAME_FILES_MODIFIED=True","NOT_INSTALLED=True") | Set-Content -LiteralPath (Join-Path $out 'MANIFEST.txt')
  Write-Host "BUILD ONLY SUCCESS. DLL: $dll"
  Write-Host 'No game files changed. Do not manually install trial DLL before deployment validation.'
} catch { "ERROR: $_" | Out-File -FilePath (Join-Path $out 'Error.txt'); Write-Error $_; exit 1 }
