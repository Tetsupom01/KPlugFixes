@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp001_BuildPackage.ps1"
set "EC=%ERRORLEVEL%"
echo.
if not "%EC%"=="0" (echo BUILD STOPPED. See OfficialBuildResult\Result.txt.) else (echo BUILD OUTPUT READY. No game files changed.)
pause
exit /b %EC%
