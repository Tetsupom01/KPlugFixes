﻿$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$out=Join-Path $root 'OfficialBuildResult'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$result=Join-Path $out 'Result.txt'
$refSource='0A339495C50796FF696BD0196D8E28CCE47218D26FDD5D98417B492B6F530F52'
$trialSHA='B0D559B8A066145D942E4B438B9459038007BDDA4B2850FD2B901CB20579D55A'
try {
 $src=Join-Path $root 'KPlugCrossFaderCompatFix_v1.2.0.cs'
 $sourceSHA=(Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToUpperInvariant()
 if($sourceSHA -ne $refSource){throw ('SOURCE_MISMATCH='+$sourceSHA)}
 # Keep trial's successful build parameters, CLR2 references, and reference-SHA gates.
 & (Join-Path $root 'BuildOnly.ps1') -GameRoot 'F:\illusion\Koikatu'
 if($LASTEXITCODE -ne 0){throw 'BUILD_SCRIPT_FAILED'}
 $built=Join-Path $root 'BuildOutput\KPlugCrossFaderCompatFix_OUT_A_Insert_TRIAL.dll'
 if(!(Test-Path -LiteralPath $built)){throw 'BUILT_DLL_MISSING'}
 $sha=(Get-FileHash -LiteralPath $built -Algorithm SHA256).Hash.ToUpperInvariant()
 $lib=Join-Path $out 'candidate\BepInEx\plugins'
 New-Item -ItemType Directory -Force -Path $lib | Out-Null
 $dest=Join-Path $lib 'KPlugCrossFaderCompatFix.dll'
 Copy-Item -LiteralPath $built -Destination $dest -Force
 if((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToUpperInvariant() -ne $sha){throw 'COPY_SHA_MISMATCH'}
 $same=$sha -eq $trialSHA
 $m=@(
  'STATUS=BUILT_CANDIDATE_NOT_INSTALLED',
  'RuntimePluginVersion=1.2.0',
  'SourceSHA256='+$sourceSHA,
  'BuiltDLLSHA256='+$sha,
  'SameAsObservedTrialDLL='+$same,
  'DiagnosticLogsDefault=OFF',
  'DiagnosticLogFile=BepInEx/KPlugCrossFaderCompatFix.log',
  'ExtraIKLogFile=NONE',
  'LoggingToggle=BepInEx/config/tetsupom.kplug.crossfader.compatfix.cfg Logging.EnableDiagnosticLogs',
  'ObservedTrialDLLSHA256='+$trialSHA,
  'GameRoot=F:\illusion\Koikatu',
  'Installed=False',
  'Published=False',
  'NeedsValidation=True',
  'KnownIssue=First Enter after post-climax HPoint move can transiently displace hands/body',
  'Unverified=Insert state suppression not observed in 2026-11-03 test'
 )
 $m|Set-Content -LiteralPath (Join-Path $out 'MANIFEST.txt') -Encoding UTF8
 $m|Set-Content -LiteralPath $result -Encoding UTF8
 $zip=Join-Path $out 'KPlugCrossFaderCompatFix_v1.2.0_CandidateForValidation.zip'
 if(Test-Path $zip){Remove-Item $zip -Force}
 Compress-Archive -Path (Join-Path $out 'candidate\*') -DestinationPath $zip
 @('ZIPSHA256='+(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash) | Add-Content -LiteralPath $result
 @('SOURCE_SHA256='+$sourceSHA,'DLL_SHA256='+$sha,'SAME_AS_OBSERVED_TRIAL='+$same,'ZIP_SHA256='+(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash) | Set-Content -LiteralPath (Join-Path $out 'SHA256SUMS.txt') -Encoding UTF8
 Copy-Item -LiteralPath (Join-Path $root 'BuildOutput\Build.log') -Destination (Join-Path $out 'Compile.log') -Force
 Write-Host 'BUILT successfully; NO GAME FILES MODIFIED.'
 Write-Host ('Candidate ZIP: '+$zip)
 Write-Host ('DLL SHA256: '+$sha)
 Write-Host ('Same binary as observed trial: '+$same)
 Write-Host 'Logging is OFF by default. Submit candidate ZIP and Result.txt. Do not deploy before approval.'
} catch {
 ('STATUS=FAILED','ERROR='+$_.Exception.Message) | Set-Content -LiteralPath $result -Encoding UTF8
 Write-Error $_
 exit 1
}
